using PicardLefschetzIntegration
using Plots
using FFTW

m    = 1.0
hbar = 1.0
a    = 1.0                     
x0   = 0.0
nmax = 5                      

F  = 0.0
V0 = 1.0

V(z) = F*z + V0
c = sqrt(m / (2*pi*im*hbar*a))

function asymptotic_action(Q, n)
    return m*(Q-x0)^2/(2*a*n) - a*F*(n-1)*(x0+Q)/2 -
           a*(n-1)*V0 - a^3*F^2*n*(n^2-1)/(24*m)
end

function phase(z, Q, n)
    kinetic = m*(z-Q)^2/(2*a)
    return (asymptotic_action(z, n-1) + kinetic - a*V(z)) / hbar
end

pars = parameters(δ=0.05, τ=-45.0, ϵ=0.01, N=800, n=12, dim=1)
Q_coarse = collect(-10.0:2.0:10.0)
dQ = 0.05
Q_fine = collect(-10.0:dQ:(10.0-dQ))  

function calculate_J(n)
    thimbles = []
    for Q in Q_coarse
        S = q -> phase(q[1], Q, n)
        contour = initialGrid([-20.0], [20.0], pars)
        flow!(S, contour, pars)
        push!(thimbles, contour)
    end

    J = ComplexF64[]
    for Q in Q_fine
        j = argmin(abs.(Q_coarse .- Q))
        S = q -> phase(q[1], Q, n)
        integral = PL_integrate(S, deepcopy(thimbles[j]), pars)
        push!(J, c/sqrt(n-1) * integral)
    end
    return J
end


function Jbar(Q, n)
    return exp(im*asymptotic_action(Q, n)/hbar) / sqrt(n)
end


k = 2*pi .* fftfreq(length(Q_fine), 1/dQ)

I = []
push!(I, exp.(im*m .* (Q_fine .- x0).^2 ./ (2*a*hbar))) 
push!(I, calculate_J(2))                           

for n in 3:nmax
    local J = calculate_J(n)
    local delta_I = I[n-1] .- Jbar.(Q_fine, n-1)

    local transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
    local correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))

    push!(I, J .+ correction)
end

p = plot(layout=(nmax-2, 1), size=(900, 900))
for n in 3:nmax
    local panel = n-2
    plot!(p, Q_fine, real.(I[n]), subplot=panel, label="Re I",
          title="I_$n", xlabel="Q_n", ylabel="I_n")
    plot!(p, Q_fine, imag.(I[n]), subplot=panel, label="Im I")
end
display(p)
