using FFTW
using Plots
using Base.Threads

function main()
    println("Julia threads: ", Threads.nthreads())

    m    = 1.0
    hbar = 0.25
    nmax = 100
    V0   = 1.0
    x0   = -5.0

    V(x) = V0 / cosh(x)^2

    Qmax = 480
    N = 65536
    dQ = 2*Qmax/N
    Q_fine = collect(range(-Qmax, step=dQ, length=N))
    k = 2*pi .* fftfreq(N, 1/dQ)

    free_I(Q, n, x0, a) = exp(im*m*(Q-x0)^2/(2*a*n*hbar)) / sqrt(n)

    function potential_sum(Q, n, x0)
        total = 0.0
        for j in 1:(n-1)
            total += V(x0 + j*(Q-x0)/n)
        end
        return total
    end

    Jbar(Q, n, x0, a) = free_I(Q, n, x0, a) * exp(-im*a*potential_sum(Q, n, x0)/hbar)

    function calculate_J(n, x0, a)
        delta = exp.(-im*a .* potential_sum.(Q_fine, n, x0) ./ hbar) .- 1
        multiplier = exp.(-im*a*hbar*n .* k.^2 ./ (2*m*(n-1)))
        correction = ifft(fft(delta) .* multiplier)
        return free_I.(Q_fine, n, x0, a) .* (1 .+ correction)
    end

    function calculate_I(x0, a)
        I = [free_I.(Q_fine, 1, x0, a), calculate_J(2, x0, a)]
        for n in 3:nmax
            delta_I = I[n-1] .- Jbar.(Q_fine, n-1, x0, a)
            transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
            correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
            push!(I, calculate_J(n, x0, a) .+ correction)
        end
        return I[nmax]
    end

    keep = abs.(Q_fine) .<= 20
    T_values = collect(0.7:0.1:10.0)
    G2 = Matrix{Float64}(undef, length(T_values), count(keep))

    function calculate_density(T)
        a = T/nmax
        amplitude = calculate_I(x0, a)
        return m/(2*pi*hbar*a) .* abs2.(amplitude[keep])
    end

    Threads.@threads for j in eachindex(T_values)
        G2[j, :] = calculate_density(T_values[j])
    end

    p = heatmap(Q_fine[keep], T_values, G2,
        xlabel="x1", ylabel="T", title="|G(x1, -5, T)|²",
        color=cgrad([:royalblue, :white, :yellow, :red]),
        colorbar_title="|G|²",
        xlims=(-20, 20), ylims=(0.7, 10),
        size=(900, 700), fmt=:png)
    display(p)
end

main()
