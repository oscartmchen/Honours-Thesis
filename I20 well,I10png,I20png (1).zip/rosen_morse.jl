using FFTW
using Plots

m    = 1.0
hbar = 1.0
a    = 0.1
x0   = 0.0
nmax = 20
V0   = 1.0

V(x) = V0 / cosh(x)^2

Qmax = 60.0
N    = 4096
dQ   = 2*Qmax/N
Q_fine = collect(range(-Qmax, step=dQ, length=N))
k = 2*pi .* fftfreq(N, 1/dQ)

free_I(Q, n) = exp(im*m*(Q-x0)^2/(2*a*n*hbar)) / sqrt(n)

function potential_sum(Q, n)
    total = 0.0
    for j in 1:(n-1)
        total += V(x0 + j*(Q-x0)/n)
    end
    return total
end

Jbar(Q, n) = free_I(Q, n) * exp(-im*a*potential_sum(Q, n)/hbar)

function calculate_J(n)
    delta = exp.(-im*a .* potential_sum.(Q_fine, n) ./ hbar) .- 1
    multiplier = exp.(-im*a*hbar*n .* k.^2 ./ (2*m*(n-1)))
    correction = ifft(fft(delta) .* multiplier)
    return free_I.(Q_fine, n) .* (1 .+ correction)
end

I = [free_I.(Q_fine, 1), calculate_J(2)]

for n in 3:nmax
    delta_I = I[n-1] .- Jbar.(Q_fine, n-1)
    transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
    correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
    push!(I, calculate_J(n) .+ correction)
end

c = sqrt(m/(2*pi*im*hbar*a))
endpoint_factor = c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar))
G = [endpoint_factor .* In for In in I]

p = plot(layout=(nmax-1, 1), size=(900, 300*(nmax-1)))
for n in 2:nmax
    plot!(p, Q_fine, real.(I[n]), subplot=n-1, label="Re I",
          title="I_$n", xlabel="Q", ylabel="I_n", xlims=(-10, 10))
    plot!(p, Q_fine, imag.(I[n]), subplot=n-1, label="Im I")
end
display(p)
