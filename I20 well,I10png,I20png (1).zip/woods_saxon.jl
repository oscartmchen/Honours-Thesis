using PicardLefschetzIntegration
using Plots
using FFTW

m    = 1.0
hbar = 1.0
a    = 1.0
x0   = 0.0
nmax = 20

V0    = 1.0
alpha = 1.0

V(z) = (V0/2) * (1 + tanh(alpha*z))
c = sqrt(m / (2*pi*im*hbar*a))

function asymptotic_action(Q, n)
    potential_sum = 0.0
    for j in 1:(n-1)
        potential_sum += V(x0 + j*(Q-x0)/n)
    end
    return m*(Q-x0)^2/(2*a*n) - a*potential_sum
end

function phase(z, Q, n)
    kinetic = m*(z-Q)^2/(2*a)
    return (asymptotic_action(z, n-1) + kinetic - a*V(z)) / hbar
end

function Jbar(Q, n)
    return exp(im*asymptotic_action(Q, n)/hbar) / sqrt(n)
end

pars = parameters(δ=0.2, τ=-25.0, ϵ=0.005, N=200, n=12, dim=1)

dQ = 0.1
Qmax = nmax == 2 ? 10.0 : 30.0
Q_coarse = collect(-Qmax:5.0:Qmax)
Q_fine = collect(-Qmax:dQ:(Qmax-dQ))
zmax = Qmax + 10.0

println("Building the initial mesh ...")
initial_contour = initialGrid([-zmax], [zmax], pars)

function calculate_J(n)
    thimbles = []
    for Q in Q_coarse
        println("J_", n, ": flowing contour at Q = ", Q)
        S = q -> phase(q[1], Q, n)
        contour = deepcopy(initial_contour)
        flow!(S, contour, pars)
        push!(thimbles, contour)
    end

    println("J_", n, ": evaluating ", length(Q_fine), " integrals ...")
    J = ComplexF64[]
    for Q in Q_fine
        j = argmin(abs.(Q_coarse .- Q))
        S = q -> phase(q[1], Q, n)
        integral = PL_integrate(S, deepcopy(thimbles[j]), pars)
        push!(J, c/sqrt(n-1) * integral)
    end

    return J
end

k = 2*pi .* fftfreq(length(Q_fine), 1/dQ)

I = []
push!(I, exp.(im*m .* (Q_fine .- x0).^2 ./ (2*a*hbar)))
push!(I, calculate_J(2))

for n in 3:nmax
    local J = calculate_J(n)
    local delta_I = I[n-1] .- Jbar.(Q_fine, n-1)
    local transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
    local correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
    push!(I, J .+ correction)
end

G = []
for n in 1:nmax
    push!(G, c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar)) .* I[n])
end

p = plot(layout=(nmax-1, 1), size=(900, 300*(nmax-1)))
for n in 2:nmax
    local panel = n-1
    plot!(p, Q_fine, real.(I[n]), subplot=panel, label="Re I",
          title="I_$n", xlabel="Q", ylabel="I_n")
    plot!(p, Q_fine, imag.(I[n]), subplot=panel, label="Im I")
end
display(p)