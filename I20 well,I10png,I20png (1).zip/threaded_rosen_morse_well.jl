using FFTW
using Plots
using Base.Threads

function main()
    println("Julia threads: ", Threads.nthreads())

    m    = 1.0
    hbar = 0.25
    a    = 0.5
    nmax = 20
    V0   = 1.0

    V(x) = - V0 / cosh(x)^2

    Qmax = 480
    N = 65536
    dQ = 2*Qmax/N
    Q_fine = collect(range(-Qmax, step=dQ, length=N))
    k = 2*pi .* fftfreq(N, 1/dQ)

    free_I(Q, n, x0) = exp(im*m*(Q-x0)^2/(2*a*n*hbar)) / sqrt(n)

    function potential_sum(Q, n, x0)
        total = 0.0
        for j in 1:(n-1)
            total += V(x0 + j*(Q-x0)/n)
        end
        return total
    end

    Jbar(Q, n, x0) = free_I(Q, n, x0) * exp(-im*a*potential_sum(Q, n, x0)/hbar)

    function calculate_J(n, x0)
        delta = exp.(-im*a .* potential_sum.(Q_fine, n, x0) ./ hbar) .- 1
        multiplier = exp.(-im*a*hbar*n .* k.^2 ./ (2*m*(n-1)))
        correction = ifft(fft(delta) .* multiplier)
        return free_I.(Q_fine, n, x0) .* (1 .+ correction)
    end

    function calculate_I(x0)
        I = [free_I.(Q_fine, 1, x0), calculate_J(2, x0)]
        for n in 3:nmax
            delta_I = I[n-1] .- Jbar.(Q_fine, n-1, x0)
            transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
            correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
            push!(I, calculate_J(n, x0) .+ correction)
        end
        return I[nmax]
    end

    x0_values = collect(range(-15.0, 15.0, length=500))
    I20 = Matrix{ComplexF64}(undef, N, length(x0_values))

    Threads.@threads for j in eachindex(x0_values)
        I20[:, j] = calculate_I(x0_values[j])
    end

    keep = abs.(Q_fine) .<= 15
    p = heatmap(x0_values, Q_fine[keep], abs.(I20[keep, :]),
        xlabel="x0", ylabel="x1", title="|I_20(x1, x0)|",
        color=:viridis, colorbar_title="|I_20|",
        xlims=(-15, 15), ylims=(-15, 15),
        size=(900, 700), fmt=:png);
    display(p)
end

main()
