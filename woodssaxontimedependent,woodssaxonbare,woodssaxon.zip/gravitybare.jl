using PicardLefschetzIntegration

pars = parameters(δ = 0.1, τ = -10., ϵ = 0.1, N = 20, n = 8, dim = 1)

M = 1.
g = 9.81
hbar = 1.
tfinal = 1.

L(p) = -M * g * p[1]
S(p) = tfinal * L(p)
Phi(p) = S(p) / hbar

thim = initialGrid([-4], [4], pars)

PL_integrate(Phi, thim, pars)