using PicardLefschetzIntegration

pars = parameters(
    δ = 1.,
    τ = -10.,
    ϵ = 0.1,
    N = 20,
    n = 5,
    dim = 3
)

S(p, zi, zf, M, g, Δt) =
    M / (2 * Δt) * (
        (p[1] - zi)^2 +
        (p[2] - p[1])^2 +
        (p[3] - p[2])^2 +
        (zf - p[3])^2
    ) -
    M * g * Δt * (
        (zi + p[1]) / 2. +
        (p[1] + p[2]) / 2. +
        (p[2] + p[3]) / 2. +
        (p[3] + zf) / 2.
    )

zi = 0.
zf = 0.

M = 1.
g = 9.81
ħ = 1.

tfinal = 1.
Nsteps = 4
Δt = tfinal / Nsteps

thim = initialGrid(
    [-4, -4, -4],
    [4, 4, 4],
    pars
)

flow!(
    p -> S(p, zi, zf, M, g, Δt) / ħ,
    thim,
    pars
)

data = PL_integrate(
    p -> S(p, zi, zf, M, g, Δt) / ħ,
    thim,
    pars
)

prefactor = (
    M / (2π * im * ħ * Δt)
)^(Nsteps / 2)

K = prefactor * data

println("Raw integral = ", data)
println("Propagator   = ", K)