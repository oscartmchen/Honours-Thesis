using PicardLefschetzIntegration

pars = parameters(
    δ = 1.,
    τ = -10.,
    ϵ = 0.1,
    N = 20,
    n = 5,
    dim = 3
)

V(x, V₀, α) = V₀ / (1 + exp(-2 * α * x))

S(p, xi, xf, m, V₀, α, Δt) =
    m / (2 * Δt) * (
        (p[1] - xi)^2 +
        (p[2] - p[1])^2 +
        (p[3] - p[2])^2 +
        (xf - p[3])^2
    ) -
    Δt * (
        V((xi + p[1]) / 2., V₀, α) +
        V((p[1] + p[2]) / 2., V₀, α) +
        V((p[2] + p[3]) / 2., V₀, α) +
        V((p[3] + xf) / 2., V₀, α)
    )

xi = 0.
xf = 0.

m = 1.
V₀ = 1.
α = 1.
ħ = 1.

tfinal = 1.
Nsteps = 4
Δt = tfinal / Nsteps

thim = initialGrid(
    [-4, -4, -4],
    [4, 4, 4],
    pars
)

flow!(
    p -> S(p, xi, xf, m, V₀, α, Δt) / ħ,
    thim,
    pars
)

data = PL_integrate(
    p -> S(p, xi, xf, m, V₀, α, Δt) / ħ,
    thim,
    pars
)

prefactor = (
    m / (2π * im * ħ * Δt)
)^(Nsteps / 2)

K = prefactor * data

println("Raw integral = ", data)
println("Propagator   = ", K)