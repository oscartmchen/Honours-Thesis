using QuadGK

V0 = 1.
alpha = 1.
m = 1.
hbar = 1.

x0 = 1.
xf = 2.

Vws(x) =
    V0 / (1 + exp(-2. * alpha * x))

xdot64(x, E) =
    sqrt(
        complex(
            2. * (E - Vws(x)) / m
        )
    )

L73(x, E) =
    m * xdot64(x, E)^2 / 2. -
    Vws(x)

function calculate(E)
    travelTime, _ = quadgk(
        x -> 1. / xdot64(x, E),
        x0,
        xf
    )

    action, _ = quadgk(
        x -> L73(x, E) / xdot64(x, E),
        x0,
        xf
    )

    println("E = ", E)
    println("Travel time = ", travelTime)
    println("Action      = ", action)
    println("exp(iS/hbar) = ", exp(im * action / hbar))
    println()
end

calculate(1.5)  # E > V(x) throughout the interval
calculate(0.5)  # E < V(x) throughout the interval