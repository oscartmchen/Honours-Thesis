using PicardLefschetzIntegration

pars = parameters(δ = 0.1, τ = -10., ϵ = 0.1, N = 20, n = 8, dim = 1)

V0 = 1.
alpha = 1.
hbar = 1.
tfinal = 1.

V(p) = V0 / (1 + exp(-2. * alpha * p[1]))
L(p) = -V(p)
S(p) = tfinal * L(p)
Phi(p) = S(p) / hbar

thim = initialGrid([-5], [5], pars)

PL_integrate(Phi, thim, pars)