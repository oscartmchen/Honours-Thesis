using PicardLefschetzIntegration

pars = parameters(δ = 0.5, τ = -10., ϵ = 0.1, N = 20, n = 5, dim = 1)

Sfree(za, zb, ta, tb, M) = M * (zb - za)^2 / (2. * (tb - ta))

S(p, z₀, z₂, t₀, t₁, t₂, M, kL, ωL, laserPhase, ħ) =
    Sfree(z₀, p[1], t₀, t₁, M) +
    Sfree(p[1], z₂, t₁, t₂, M) +
    ħ * (kL * p[1] - ωL * t₁ - laserPhase)

z₀, z₂ = 0., 0.
t₀, t₁, t₂ = 0., 0.5, 1.

M = 1.
ħ = 1.

kL = 1.
ωL = 1.
laserPhase = 0.

Uβα = 1. + 0im

thim = initialGrid([-4], [4], pars)

flow!(
    p -> S(p, z₀, z₂, t₀, t₁, t₂, M, kL, ωL, laserPhase, ħ) / ħ,
    thim,
    pars
)

data = PL_integrate(
    p -> S(p, z₀, z₂, t₀, t₁, t₂, M, kL, ωL, laserPhase, ħ) / ħ,
    thim,
    pars
)

data = Uβα *
    sqrt(M / (2π * im * ħ * (t₁ - t₀))) *
    sqrt(M / (2π * im * ħ * (t₂ - t₁))) *
    data

data