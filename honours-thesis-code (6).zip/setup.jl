using Pkg

Pkg.activate(@__DIR__)
Pkg.add([
    PackageSpec(name="PicardLefschetzIntegration", version="1.1.0"),
    PackageSpec(name="FFTW", version="1.10.0"),
    PackageSpec(name="Plots", version="1.41.7"),
    PackageSpec(name="FastGaussQuadrature", version="1.3.0"),
    PackageSpec(name="QuadGK", version="2.11.3"),
    PackageSpec(name="SpecialFunctions", version="2.9.1"),
    PackageSpec(name="HypergeometricFunctions", version="0.3.31"),
    PackageSpec(name="ForwardDiff", version="1.4.7"),
    PackageSpec(name="Statistics", version="1.11.5")
])
println("Julia version: ", VERSION)
println("Run calculations with julia --project=. src/<filename>.jl")
println("Install Python dependencies with python3 -m pip install -r requirements.txt")
println("The report benchmark uses Python 3.12.14")
