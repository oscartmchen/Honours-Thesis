using FastGaussQuadrature
using Plots

function main()
    I       = 1.0
    hbar    = 1.0
    T       = 1.0
    epsilon = 0.05
    z       = T-im*epsilon
    nmax    = 16
    order   = 64
    wmax    = 12
    lmax    = 80

    function winding(theta, alpha, cutoff)
        d = theta .+ 2*pi .* collect(-cutoff:cutoff)
        return sqrt(I/(2*pi*im*hbar*z)) *
            sum(exp.(im*I .* d.^2/(2*hbar*z) .+ im*alpha .* d))
    end

    function spectral(theta, alpha, cutoff)
        l = collect(-cutoff:cutoff)
        return sum(exp.(im*l*theta .- im*hbar*z .* (l .- alpha).^2/(2*I)))/(2*pi)
    end

    a = z/nmax
    x, w = gausslegendre(order)
    gaussian = sum(8*w .* exp.(-(8*x).^2))
    rotation = exp(im*(pi/4+angle(z)/2))
    factor = (I/(2*pi*im*hbar*a))^(nmax/2)
    for j in 1:(nmax-1)
        lambda = 4*sin(j*pi/(2*nmax))^2
        factor *= rotation*gaussian/sqrt(abs(I*lambda/(2*hbar*a)))
    end
    factor /= sqrt(I/(2*pi*im*hbar*z))

    alpha_values = collect(range(0.0, 1.0, length=201))
    theta_values = [0.7, pi]
    G = [winding(theta, alpha, wmax) for theta in theta_values, alpha in alpha_values]
    G_contour = factor .* G
    G_reference = [spectral(theta, alpha, lmax) for theta in theta_values, alpha in alpha_values]
    G_refined = [spectral(theta, alpha, 100) for theta in theta_values, alpha in alpha_values]
    G_winding_refined = [winding(theta, alpha, 16) for theta in theta_values, alpha in alpha_values]

    println("Contour error = ", maximum(abs.(G_contour .- G_reference)))
    println("Winding error = ", maximum(abs.(G .- G_reference)))
    println("Reference change = ", maximum(abs.(G_refined .- G_reference)))
    println("Winding cutoff change = ", maximum(abs.(G_winding_refined .- G)))
    for j in eachindex(theta_values)
        println("Mean complex error at theta = ", theta_values[j], " = ",
            sum(abs.(G_contour[j, :] .- G_reference[j, :]))/length(alpha_values))
    end
    println("Half-flux amplitude = ", abs(factor*winding(pi, 0.5, wmax)))

    p = plot(layout=(1, 2), size=(1100, 420))
    plot!(p, alpha_values, real.(G_reference[1, :]), subplot=1, label="Re G", xlabel="alpha")
    plot!(p, alpha_values, imag.(G_reference[1, :]), subplot=1, label="Im G")
    sample = 1:10:length(alpha_values)
    scatter!(p, alpha_values[sample], real.(G_contour[1, sample]), subplot=1, label="Contour: Re G")
    scatter!(p, alpha_values[sample], imag.(G_contour[1, sample]), subplot=1, label="Contour: Im G")
    plot!(p, alpha_values, abs2.(G_reference[2, :])/abs2(G_reference[2, 1]),
        subplot=2, label="Spectral", xlabel="alpha", ylabel="Relative intensity")
    scatter!(p, alpha_values[sample], abs2.(G_contour[2, sample])/abs2(G_reference[2, 1]),
        subplot=2, label="Contour")
    display(p)
end

main()
