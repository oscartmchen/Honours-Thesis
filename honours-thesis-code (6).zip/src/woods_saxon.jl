using PicardLefschetzIntegration
using Plots
using FFTW
using HypergeometricFunctions
using SpecialFunctions
using QuadGK

function main()
    m     = 1.0
    hbar  = 1.0
    V0    = 1.0
    alpha = 1.0
    x0    = 0.0
    T     = 5.0
    theta = 0.04
    smax  = 6.0

    V(z) = (V0/2) * (1 + tanh(alpha*z))

    function ws_incident(k, p)
        return exp(loggamma(1-im*p/alpha)+loggamma(-im*k/alpha)-
                   loggamma(-im*(k+p)/(2*alpha))-loggamma(1-im*(k+p)/(2*alpha)))
    end

    function ws_outgoing(x, k, p)
        sigma = im*(k-p)/(2*alpha)
        if x < 0
            u = exp(2*alpha*x)
            w = u/(1+u)
            logz = -log1p(u)
            logw = 2*alpha*x-log1p(u)
            common = -im*p*logz/(2*alpha)
            A = ws_incident(k, p)
            B = exp(loggamma(1-im*p/alpha)+loggamma(im*k/alpha)-
                    loggamma(im*(k-p)/(2*alpha))-loggamma(1+im*(k-p)/(2*alpha)))
            incoming = exp(common+im*k*logw/(2*alpha))*
                       pFq((sigma, 1+sigma), (1+im*k/alpha,), w)
            reflected = exp(common-im*k*logw/(2*alpha))*
                        pFq((1-im*(k+p)/(2*alpha), -im*(k+p)/(2*alpha)),
                            (1-im*k/alpha,), w)
            return A*incoming+B*reflected
        end
        z = 1/(1+exp(2*alpha*x))
        phase = -im*p*log(z)/(2*alpha)+im*k*log1p(-z)/(2*alpha)
        return exp(phase)*pFq((sigma, 1+sigma), (1-im*p/alpha,), z)
    end

    function ws_reference(x1)
        if V0 == 0
            return sqrt(m/(2*pi*im*hbar*T))*exp(im*m*(x1-x0)^2/(2*hbar*T))
        end
        kstar = sqrt(2*m*V0)/hbar
        function closed(vartheta)
            k = kstar*sin(vartheta)
            local p = im*kstar*cos(vartheta)
            density = ws_outgoing(x1, k, p)*ws_outgoing(x0, -k, p)/
                      (2*pi*ws_incident(k, p)*ws_incident(-k, p))
            return density*exp(-im*hbar*k^2*T/(2*m))*kstar*cos(vartheta)
        end
        function open(t)
            k = kstar+exp(-im*theta)*t^2
            local p = sqrt(k-kstar)*sqrt(k+kstar)
            phase = -im*hbar*k^2*T/(2*m)
            if real(phase) < -700
                return 0.0im
            end
            left = ws_outgoing(x1, k, p)*ws_outgoing(x0, -k, -p)/
                   (ws_incident(k, p)*ws_incident(-k, -p))
            right = ws_outgoing(-x1, p, k)*ws_outgoing(-x0, -p, -k)/
                    (ws_incident(p, k)*ws_incident(-p, -k))
            return (left+k/p*right)/(2*pi)*exp(phase)*2*t*exp(-im*theta)
        end
        Gc, error = quadgk(closed, 0.0, pi/2; rtol=1e-10, atol=5e-12)
        Go, error = quadgk(open, 0.0, smax; rtol=1e-10, atol=5e-12)
        return Gc+Go
    end

    function calculate_G(nmax)
        a = T/nmax

        c = sqrt(m / (2*pi*im*hbar*a))

        function asymptotic_action(Q, n)
            potential_sum = 0.0
            for j in 1:(n-1)
                potential_sum += V(x0 + j*(Q-x0)/n)
            end
            return m*(Q-x0)^2/(2*a*n) - a*potential_sum
        end

        function phase(z, Q, n)
            kinetic = m*(z-Q)^2/(2*a)
            return (asymptotic_action(z, n-1) + kinetic - a*V(z)) / hbar
        end

        function Jbar(Q, n)
            return exp(im*asymptotic_action(Q, n)/hbar) / sqrt(n)
        end

        pars = parameters(δ=0.2, τ=-25.0, ϵ=0.005, N=200, n=12, dim=1)

        dQ = 0.1
        Qmax = nmax == 2 ? 10.0 : 30.0
        Q_coarse = collect(-Qmax:5.0:Qmax)
        Q_fine = collect(-Qmax:dQ:(Qmax-dQ))
        zmax = Qmax + 10.0

        println("Building the initial mesh ...")
        initial_contour = initialGrid([-zmax], [zmax], pars)

        function calculate_J(n)
            thimbles = []
            for Q in Q_coarse
                println("J_", n, ": flowing contour at Q = ", Q)
                S = q -> phase(q[1], Q, n)
                contour = deepcopy(initial_contour)
                flow!(S, contour, pars)
                push!(thimbles, contour)
            end

            println("J_", n, ": evaluating ", length(Q_fine), " integrals ...")
            J = ComplexF64[]
            for Q in Q_fine
                j = argmin(abs.(Q_coarse .- Q))
                S = q -> phase(q[1], Q, n)
                integral = PL_integrate(S, deepcopy(thimbles[j]), pars)
                push!(J, c/sqrt(n-1) * integral)
            end

            return J
        end

        k = 2*pi .* fftfreq(length(Q_fine), 1/dQ)

        I = []
        push!(I, exp.(im*m .* (Q_fine .- x0).^2 ./ (2*a*hbar)))
        push!(I, calculate_J(2))

        for n in 3:nmax
            local J = calculate_J(n)
            local delta_I = I[n-1] .- Jbar.(Q_fine, n-1)
            local transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
            local correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
            push!(I, J .+ correction)
        end


        endpoint_factor = c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar))
        return Q_fine, endpoint_factor .* I[nmax]

    end

    x = collect(range(-10.0, 10.0, length=201))
    G_reference = ws_reference.(x)
    p = plot(layout=(3, 1), size=(900, 900))
    plot!(p, x, real.(G_reference), subplot=1, label="Spectral reference", xlabel="x1", ylabel="Re G")
    plot!(p, x, imag.(G_reference), subplot=2, label="Spectral reference", xlabel="x1", ylabel="Im G")
    plot!(p, x, abs2.(G_reference), subplot=3, label="Spectral reference", xlabel="x1", ylabel="|G|²")
    for nmax in [5, 20]
        Q, G = calculate_G(nmax)
        dQ = Q[2]-Q[1]
        indices = round.(Int, (x .- Q[1]) ./ dQ) .+ 1
        values = G[indices]
        difference = abs.(values .- G_reference)
        mean_error = sum(diff(x) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x[end]-x[1]))
        println("N = ", nmax, ", mean complex error = ", mean_error)
        plot!(p, x, real.(values), subplot=1, label="N = $nmax")
        plot!(p, x, imag.(values), subplot=2, label="N = $nmax")
        plot!(p, x, abs2.(values), subplot=3, label="N = $nmax")
    end
    display(p)
end

main()
