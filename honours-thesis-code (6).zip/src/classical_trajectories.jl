using ForwardDiff
using Plots

function main()
    m     = 1.0
    V0    = 1.0
    alpha = 1.0
    x0    = 5.0
    x1    = 4.0
    T     = 10.0
    s     = 1

    function classical_position(t, x0, v0, s)
        u0 = sinh(alpha*x0)
        c0 = cosh(alpha*x0)
        du0 = alpha*v0*c0
        E = m*v0^2/2+s*V0/c0^2
        K = 2*alpha^2*E/m
        if abs(K)*t^2 < 1e-7
            C = 1+K*t^2/2+K^2*t^4/24+K^3*t^6/720
            S = t+K*t^3/6+K^2*t^5/120+K^3*t^7/5040
            u = u0*C+du0*S
        elseif E > 0
            omega = sqrt(K)
            if x0 == 0
                return asinh(du0*sinh(omega*t)/omega)/alpha
            end
            q = du0/omega
            product = (2*s*V0*tanh(alpha*x0)^2/m-v0^2)/(2*E/m)
            if abs(u0+q) < abs(u0-q)
                B = (u0-q)/2
                A = product/(4*B)
            else
                A = (u0+q)/2
                B = product/(4*A)
            end
            u = A*exp(omega*t)+B*exp(-omega*t)
        else
            omega = sqrt(-K)
            u = u0*cos(omega*t)+du0*sin(omega*t)/omega
        end
        return asinh(u)/alpha
    end

    function bisect(f, lo, hi)
        flo = f(lo)
        for j in 1:48
            midpoint = (lo+hi)/2
            if flo*f(midpoint) > 0
                lo = midpoint
                flo = f(lo)
            else
                hi = midpoint
            end
        end
        return (lo+hi)/2
    end

    arrival(v) = classical_position(T, x0, v, s)
    J(v) = ForwardDiff.derivative(arrival, v)
    velocities = collect(range(-2.0, 1.0, length=601))
    arrivals = arrival.(velocities)
    jacobians = J.(velocities)
    connections = Float64[]
    folds = Float64[]
    for j in 1:(length(velocities)-1)
        lo, hi = velocities[j], velocities[j+1]
        if (arrivals[j]-x1)*(arrivals[j+1]-x1) < 0
            push!(connections, bisect(v -> arrival(v)-x1, lo, hi))
        end
        if jacobians[j]*jacobians[j+1] < 0
            push!(folds, bisect(J, lo, hi))
        end
    end
    println("Connecting initial velocities = ", connections)
    println("Fold arrival positions = ", arrival.(folds))

    p = plot(layout=(1, 2), size=(1100, 450))
    plot!(p, velocities, arrivals, subplot=1, xlabel="v0", ylabel="x(T)", label="Arrival map")
    hline!(p, [x1], subplot=1, label="x1")
    scatter!(p, connections, fill(x1, length(connections)), subplot=1, label="Connections")
    scatter!(p, folds, arrival.(folds), subplot=1, label="Folds")
    times = collect(range(0.0, T, length=1001))
    for v in connections
        path = [classical_position(t, x0, v, s) for t in times]
        plot!(p, times, path, subplot=2, xlabel="t", ylabel="x(t)", label="v0 = $(round(v, digits=5))")
    end
    display(p)
end

main()
