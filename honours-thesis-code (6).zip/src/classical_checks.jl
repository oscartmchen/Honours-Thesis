using Plots

function main()
    m     = 1.0
    V0    = 1.0
    alpha = 1.0
    x0    = 0.0
    T     = 5.0
    steps = 2000

    function derivative(q)
        u = tanh(alpha*q[1])
        force = -alpha*V0*(1-u^2)/(2*m)
        gradient = alpha^2*V0*(1-u^2)*u/m
        return [q[2], force, q[4], gradient*q[3]]
    end

    function arrival(v0)
        q = [x0, v0, 0.0, 1.0]
        dt = T/steps
        for j in 1:steps
            k1 = derivative(q)
            k2 = derivative(q .+ dt/2 .* k1)
            k3 = derivative(q .+ dt/2 .* k2)
            k4 = derivative(q .+ dt .* k3)
            q .+= dt/6 .* (k1 .+ 2 .* k2 .+ 2 .* k3 .+ k4)
        end
        return q
    end

    function initial_velocity(target)
        lo = -10.0
        hi = 10.0
        for j in 1:48
            midpoint = (lo+hi)/2
            if arrival(midpoint)[1] < target
                lo = midpoint
            else
                hi = midpoint
            end
        end
        return (lo+hi)/2
    end

    velocities = collect(range(initial_velocity(-10.0), initial_velocity(10.0), length=401))
    states = arrival.(velocities)
    positions = [q[1] for q in states]
    jacobians = [q[3] for q in states]
    println("Minimum arrival derivative = ", minimum(jacobians))
    p = plot(layout=(2, 1), size=(900, 700))
    plot!(p, velocities, positions, subplot=1, xlabel="v0", ylabel="x(T)", label="Arrival map")
    plot!(p, velocities, jacobians, subplot=2, xlabel="v0", ylabel="J(T)", label="Derivative")
    hline!(p, [0.0], subplot=2, label="Caustic condition")
    display(p)
end

main()
