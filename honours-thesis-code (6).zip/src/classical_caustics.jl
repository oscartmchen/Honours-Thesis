using ForwardDiff
using Plots

function main()
    m     = 1.0
    V0    = 1.0
    alpha = 1.0
    T     = 10.0

    function classical_position(t, x0, v0, s)
        u0 = sinh(alpha*x0)
        c0 = cosh(alpha*x0)
        du0 = alpha*v0*c0
        E = m*v0^2/2+s*V0/c0^2
        K = 2*alpha^2*E/m
        if abs(K)*t^2 < 1e-7
            C = 1+K*t^2/2+K^2*t^4/24+K^3*t^6/720
            S = t+K*t^3/6+K^2*t^5/120+K^3*t^7/5040
            u = u0*C+du0*S
        elseif E > 0
            omega = sqrt(K)
            if x0 == 0
                return asinh(du0*sinh(omega*t)/omega)/alpha
            end
            q = du0/omega
            product = (2*s*V0*tanh(alpha*x0)^2/m-v0^2)/(2*E/m)
            if abs(u0+q) < abs(u0-q)
                B = (u0-q)/2
                A = product/(4*B)
            else
                A = (u0+q)/2
                B = product/(4*A)
            end
            u = A*exp(omega*t)+B*exp(-omega*t)
        else
            omega = sqrt(-K)
            u = u0*cos(omega*t)+du0*sin(omega*t)/omega
        end
        return asinh(u)/alpha
    end

    function bisect(f, lo, hi)
        flo = f(lo)
        for j in 1:48
            midpoint = (lo+hi)/2
            if flo*f(midpoint) > 0
                lo = midpoint
                flo = f(lo)
            else
                hi = midpoint
            end
        end
        return (lo+hi)/2
    end

    sources = collect(range(-15.0, 15.0, length=301))
    velocities = collect(range(-4.0, 4.0, length=1601))
    p = plot(layout=(1, 2), size=(1100, 450))
    for (panel, s) in enumerate((1, -1))
        x0_values = Float64[]
        x1_values = Float64[]
        for x0 in sources
            arrival(v) = classical_position(T, x0, v, s)
            J(v) = ForwardDiff.derivative(arrival, v)
            values = J.(velocities)
            for j in 1:(length(velocities)-1)
                if values[j]*values[j+1] < 0
                    v = bisect(J, velocities[j], velocities[j+1])
                    x1 = arrival(v)
                    if abs(x1) <= 15
                        push!(x0_values, x0)
                        push!(x1_values, x1)
                    end
                end
            end
        end
        scatter!(p, x0_values, x1_values, subplot=panel, markersize=1,
            xlabel="x0", ylabel="x1", label=s == 1 ? "Barrier" : "Well",
            xlims=(-15, 15), ylims=(-15, 15))
    end
    display(p)
end

main()
