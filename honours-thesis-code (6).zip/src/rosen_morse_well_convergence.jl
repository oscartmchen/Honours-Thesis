using FFTW
using HypergeometricFunctions
using SpecialFunctions
using QuadGK
using Plots

function main()
    m     = 1.0
    hbar  = 0.25
    V0    = 1.0
    alpha = 1.0
    s     = -1
    x0    = 0.0
    T     = 10.0
    theta = 0.04
    kmax  = 40.0

    N_values = [10, 20, 40, 80, 160, 320]
    L_values = [128.0, 256.0, 512.0, 1024.0, 2048.0, 2048.0]
    M_values = [4096, 16384, 65536, 262144, 1048576, 1048576]

    function rm_lambda()
        return -0.5 + sqrt(complex(0.25-2*m*s*V0/(hbar^2*alpha^2)))
    end

    function rm_outgoing(x, k)
        lambda = rm_lambda()
        z = (1-tanh(alpha*x))/2
        return exp(im*k*x)*pFq((-lambda, lambda+1), (1-im*k/alpha,), z)
    end

    function rm_coefficients(k)
        lambda = rm_lambda()
        q = k/alpha
        common = im*q*log(2)+log(pi)/2+loggamma(1-im*q)
        a = exp(common-loggamma((1-lambda-im*q)/2)-loggamma((2+lambda-im*q)/2))
        b = -2*alpha*exp(common-loggamma((-lambda-im*q)/2)-loggamma((1+lambda-im*q)/2))
        return a, b
    end

    function rm_parity(x, k)
        if abs(alpha*x) > 2.5
            f = rm_outgoing(abs(x), k)
            fm = rm_outgoing(abs(x), -k)
            a, b = rm_coefficients(k)
            am, bm = rm_coefficients(-k)
            C = (bm*f-b*fm)/(-2*im*k)
            S = (a*fm-am*f)/(-2*im*k)
            if x < 0
                return C, -S
            end
            return C, S
        end
        lambda = rm_lambda()
        q = k/alpha
        y = tanh(alpha*x)
        factor = exp(-im*q*log1p(-y*y)/2)
        C = factor*pFq(((-lambda-im*q)/2, (lambda+1-im*q)/2), (0.5,), y*y)
        S = y/alpha*factor*pFq(((1-lambda-im*q)/2, (lambda+2-im*q)/2), (1.5,), y*y)
        return C, S
    end

    function rm_continuum(x1, theta, kmax, rtol, atol)
        if V0 == 0
            return sqrt(m/(2*pi*im*hbar*T))*exp(im*m*(x1-x0)^2/(2*hbar*T))
        end
        function integrand(r)
            k = exp(-im*theta)*r
            C1, S1 = rm_parity(x1, k)
            C0, S0 = rm_parity(x0, k)
            a, b = rm_coefficients(k)
            am, bm = rm_coefficients(-k)
            density = k^2/pi*(C1*C0/(b*bm)+S1*S0/(a*am))
            return exp(-im*theta)*density*exp(-im*hbar*k^2*T/(2*m))
        end
        value, error = quadgk(integrand, 0.0, kmax; rtol=rtol, atol=atol)
        return value
    end

    function rm_state(n, x)
        lambda = real(rm_lambda())
        b = lambda-n
        if isodd(n) && x == 0
            return 0.0
        end
        z = (1-tanh(alpha*abs(x)))/2
        term = 1.0
        polynomial = 1.0
        for j in 1:n
            term *= (-n+j-1)*(n+2*b+j)*z/((b+j)*j)
            polynomial += term
        end
        polynomial *= exp(loggamma(n+b+1)-loggamma(n+1)-loggamma(b+1))
        lognorm = (log(alpha*b)+loggamma(n+1)+loggamma(n+2*b+1)-
                   2*b*log(2)-2*loggamma(n+b+1))/2
        value = exp(lognorm-b*log(cosh(alpha*x)))*polynomial
        if x < 0 && isodd(n)
            return -value
        end
        return value
    end

    function rm_bound(x1)
        if s == 1
            return 0.0im
        end
        lambda = real(rm_lambda())
        value = 0.0im
        for n in 0:(ceil(Int, lambda)-1)
            E = -hbar^2*alpha^2*(lambda-n)^2/(2*m)
            value += rm_state(n, x1)*rm_state(n, x0)*exp(-im*E*T/hbar)
        end
        return value
    end

    rm_reference(x1, theta, kmax, rtol, atol) = rm_continuum(x1, theta, kmax, rtol, atol)+rm_bound(x1)
    function rm_stitching(nmax, L, M, x0)
        a = T/nmax
        dQ = 2*L/M
        Q_fine = collect(range(-L, step=dQ, length=M))
        k = 2*pi .* fftfreq(M, 1/dQ)
        function V(x)
            u = exp(-abs(alpha*x))
            return s*V0*(2*u/(1+u^2))^2
        end
        free_I(Q, n) = exp(im*m*(Q-x0)^2/(2*a*n*hbar))/sqrt(n)
        phase_V = exp.(-im*a .* V.(Q_fine) ./ hbar)
        multiplier = exp.(-im*a*hbar .* k.^2 ./ (2*m))

        function calculate_J(n)
            potential_sum = zeros(M)
            for j in 1:(n-1)
                potential_sum .+= V.(x0 .+ j/n .* (Q_fine .- x0))
            end
            delta = exp.(-im*a .* potential_sum ./ hbar) .- 1
            background_multiplier = exp.(-im*a*hbar*n .* k.^2 ./ (2*m*(n-1)))
            J = free_I.(Q_fine, n) .* (1 .+ ifft(fft(delta) .* background_multiplier))
            return J, potential_sum
        end

        I = free_I.(Q_fine, 1)
        previous_sum = zeros(M)
        for n in 2:nmax
            J, potential_sum = calculate_J(n)
            if n > 2
                Jbar = free_I.(Q_fine, n-1) .* exp.(-im*a .* previous_sum ./ hbar)
                correction = ifft(fft((I .- Jbar) .* phase_V) .* multiplier)
                I = J .+ correction
            else
                I = J
            end
            previous_sum = potential_sum
        end
        c = sqrt(m/(2*pi*im*hbar*a))
        endpoint_factor = c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar))
        return Q_fine, endpoint_factor .* I
    end

    function rm_density(k, x1, x0)
        C1, S1 = rm_parity(x1, k)
        C0, S0 = rm_parity(x0, k)
        a, b = rm_coefficients(k)
        am, bm = rm_coefficients(-k)
        return k^2/pi*(C1*C0/(b*bm)+S1*S0/(a*am))
    end

    function rm_incident(k)
        lambda = rm_lambda()
        q = k/alpha
        return exp(loggamma(1-im*q)+loggamma(-im*q)-
            loggamma(1+lambda-im*q)-loggamma(-lambda-im*q))
    end

    density_change = 0.0
    for k in [0.4+0im, 3.0-0.1im, 10.0+0im]
        direct = (rm_outgoing(1.1, k)*rm_outgoing(-0.2, -k)+
            rm_outgoing(-1.1, k)*rm_outgoing(0.2, -k))/(2*pi*rm_incident(k)*rm_incident(-k))
        density_change = max(density_change, abs(rm_density(k, 1.1, -0.2)-direct)/(1+abs(direct)))
    end
    println("Independent hypergeometric density change = ", density_change)

    x = collect(range(-8.0, 8.0, length=129))
    G_reference = [rm_reference(q, theta, kmax, 1e-10, 1e-11) for q in x]
    checkpoints = [-4.0, 0.0, 4.0]
    G_control = [rm_reference(q, 0.04, 40.0, 1e-10, 1e-11) for q in checkpoints]
    G_refined = [rm_reference(q, 0.06, 48.0, 1e-12, 1e-13) for q in checkpoints]
    println("Float64 spectral reference refinement at ", checkpoints, " = ", maximum(abs.(G_control .- G_refined)))
    p_reference = plot(layout=(3, 1), size=(900, 900))
    plot!(p_reference, x, real.(G_reference), subplot=1, label="Reference", xlabel="x1", ylabel="Re G")
    plot!(p_reference, x, imag.(G_reference), subplot=2, label="Reference", xlabel="x1", ylabel="Im G")
    plot!(p_reference, x, abs2.(G_reference), subplot=3, label="Reference", xlabel="x1", ylabel="|G|²")
    Q = Float64[]
    G = ComplexF64[]
    errors = Float64[]
    for j in eachindex(N_values)
        Q, G = rm_stitching(N_values[j], L_values[j], M_values[j], x0)
        indices = round.(Int, (x .+ L_values[j]) ./ (Q[2]-Q[1])) .+ 1
        difference = abs.(G[indices] .- G_reference)
        mean_error = sum(diff(x) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x[end]-x[1]))
        push!(errors, mean_error)
        println("N = ", N_values[j], ", mean complex error = ", mean_error)
        if j > 1
            println("Observed order = ", log(errors[j-1]/errors[j])/log(N_values[j]/N_values[j-1]))
        end
        if N_values[j] == 20 || j == length(N_values)
            plot!(p_reference, x, real.(G[indices]), subplot=1, label="N = $(N_values[j])")
            plot!(p_reference, x, imag.(G[indices]), subplot=2, label="N = $(N_values[j])")
            plot!(p_reference, x, abs2.(G[indices]), subplot=3, label="N = $(N_values[j])")
        end
    end
    display(p_reference)

    function sample_grid(Q, G, x)
        indices = round.(Int, (x .- Q[1]) ./ (Q[2]-Q[1])) .+ 1
        return G[indices]
    end

    function mean_change(G1, G2)
        difference = abs.(G1 .- G2)
        return sum(diff(x) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x[end]-x[1]))
    end

    Q_base, G_base = rm_stitching(320, 1024.0, 524288, x0)
    println("Fixed-N domain change = ", mean_change(sample_grid(Q_base, G_base, x), sample_grid(Q, G, x)))
    Q_coarse, G_coarse = rm_stitching(320, 2048.0, 524288, x0)
    println("Fixed-N spacing change = ", mean_change(sample_grid(Q_coarse, G_coarse, x), sample_grid(Q, G, x)))

    function map_stitching(nmax, Qmax, N, x0)
        a = T/nmax
        dQ = 2*Qmax/N
        V(x) = s*V0 / cosh(alpha*x)^2
        Q_fine = collect(range(-Qmax, step=dQ, length=N))
        k = 2*pi .* fftfreq(N, 1/dQ)

        free_I(Q, n, x0) = exp(im*m*(Q-x0)^2/(2*a*n*hbar)) / sqrt(n)

        function potential_sum(Q, n, x0)
            total = 0.0
            for j in 1:(n-1)
                total += V(x0 + j*(Q-x0)/n)
            end
            return total
        end

        Jbar(Q, n, x0) = free_I(Q, n, x0) * exp(-im*a*potential_sum(Q, n, x0)/hbar)

        function calculate_J(n, x0)
            delta = exp.(-im*a .* potential_sum.(Q_fine, n, x0) ./ hbar) .- 1
            multiplier = exp.(-im*a*hbar*n .* k.^2 ./ (2*m*(n-1)))
            correction = ifft(fft(delta) .* multiplier)
            return free_I.(Q_fine, n, x0) .* (1 .+ correction)
        end

        function calculate_I(x0)
            I = [free_I.(Q_fine, 1, x0), calculate_J(2, x0)]
            for n in 3:nmax
                delta_I = I[n-1] .- Jbar.(Q_fine, n-1, x0)
                transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
                correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
                push!(I, calculate_J(n, x0) .+ correction)
            end
            return I[nmax]
        end
        return Q_fine, calculate_I(x0)
    end

    for source in [-15.0, -7.5, 0.0, 7.5, 15.0]
        Q_map, I_map = map_stitching(20, 480.0, 65536, source)
        Q_map_large, I_map_large = map_stitching(20, 960.0, 131072, source)
        Q_map_fine, I_map_fine = map_stitching(20, 480.0, 131072, source)
        keep = abs.(Q_map) .<= 15
        positions = Q_map[keep]
        println("Endpoint map x0 = ", source,
            ", domain change = ", sum(abs.(I_map[keep] .- sample_grid(Q_map_large, I_map_large, positions)))/count(keep),
            ", spacing change = ", sum(abs.(I_map[keep] .- sample_grid(Q_map_fine, I_map_fine, positions)))/count(keep))
    end

    p = plot(N_values, errors, marker=:circle, xscale=:log10, yscale=:log10,
        xlabel="N", ylabel="Mean absolute complex error", label="Well", size=(900, 600))
    display(p)
end

main()
