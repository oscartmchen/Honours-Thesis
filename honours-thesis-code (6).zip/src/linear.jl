using PicardLefschetzIntegration
using Plots
using FFTW

function main()
    m    = 1.0
    hbar = 1.0
    T    = 5.0
    x0   = 0.0
    F    = 1.0
    V0   = 1.0

    V(z) = F*z + V0

    pars = parameters(δ=0.05, τ=-45.0, ϵ=0.01, N=800, n=12, dim=1)
    Q_coarse = collect(-10.0:2.0:10.0)
    dQ = 0.1
    Q_fine = collect(-10.0:dQ:(10.0-dQ))
    k = 2*pi .* fftfreq(length(Q_fine), 1/dQ)
    x1 = collect(range(-5.0, 5.0, length=101))
    indices = round.(Int, (x1 .+ 10.0) ./ dQ) .+ 1

    function calculate_G(nmax)
        a = T/nmax
        c = sqrt(m / (2*pi*im*hbar*a))

        function asymptotic_action(Q, n)
            return m*(Q-x0)^2/(2*a*n) - a*F*(n-1)*(x0+Q)/2 -
                   a*(n-1)*V0 - a^3*F^2*n*(n^2-1)/(24*m)
        end

        function phase(z, Q, n)
            kinetic = m*(z-Q)^2/(2*a)
            return (asymptotic_action(z, n-1) + kinetic - a*V(z)) / hbar
        end

        function calculate_J(n)
            thimbles = []
            for Q in Q_coarse
                S = q -> phase(q[1], Q, n)
                contour = initialGrid([-20.0], [20.0], pars)
                flow!(S, contour, pars)
                push!(thimbles, contour)
            end

            quads = [quadrature(contour, pars) for contour in thimbles]

            J = ComplexF64[]
            for Q in Q_fine
                j = argmin(abs.(Q_coarse .- Q))
                S = q -> phase(q[1], Q, n)
                integral = PL_integrate(S, quads[j], pars)
                push!(J, c/sqrt(n-1) * integral)
            end
            return J
        end

        function Jbar(Q, n)
            return exp(im*asymptotic_action(Q, n)/hbar) / sqrt(n)
        end

        println("Stitching n = 2 of ", nmax)
        flush(stdout)
        I = []
        push!(I, exp.(im*m .* (Q_fine .- x0).^2 ./ (2*a*hbar)))
        push!(I, calculate_J(2))

        for n in 3:nmax
            println("Stitching n = ", n, " of ", nmax)
            flush(stdout)
            local J = calculate_J(n)
            local delta_I = I[n-1] .- Jbar.(Q_fine, n-1)
            local transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
            local correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
            push!(I, J .+ correction)
        end

        endpoint_factor = c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar))
        return (endpoint_factor .* I[nmax])[indices]
    end

    function classical_action(x)
        return m*(x-x0)^2/(2*T) - F*T*(x0+x)/2 - F^2*T^3/(24*m) - V0*T
    end

    println("Iterative affine stitching with Picard-Lefschetz backgrounds and Fourier corrections")
    G_reference = sqrt(m/(2*pi*im*hbar*T)) .* exp.(im .* classical_action.(x1) ./ hbar)
    N_values = [5, 80]
    errors = Float64[]
    p = plot(layout=(2, 1), size=(900, 650))
    plot!(p, x1, real.(G_reference), subplot=1, label="Exact continuum", xlabel="x1", ylabel="Re G")
    plot!(p, x1, imag.(G_reference), subplot=2, label="Exact continuum", xlabel="x1", ylabel="Im G")
    for nmax in N_values
        G = calculate_G(nmax)
        difference = abs.(G .- G_reference)
        mean_error = sum(diff(x1) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x1[end]-x1[1]))
        push!(errors, mean_error)
        println("N = ", nmax, ", mean complex error = ", mean_error)
        plot!(p, x1, real.(G), subplot=1, label="Stitching, N = $nmax")
        plot!(p, x1, imag.(G), subplot=2, label="Stitching, N = $nmax")
    end
    display(p)

    N_lattice = [5, 10, 20, 40, 80, 160, 320]
    errors_lattice = Float64[]
    for nmax in N_lattice
        delta = F^2*T^3/(24*m*hbar*nmax^2)
        lattice_error = 2*sqrt(m/(2*pi*hbar*T))*abs(sin(delta/2))
        push!(errors_lattice, lattice_error)
        println("N = ", nmax, ", analytical lattice error = ", lattice_error)
    end
    p = plot(N_lattice, errors_lattice, marker=:circle, xscale=:log10, yscale=:log10,
        xlabel="N", ylabel="Mean absolute complex error", label="Exact lattice error", size=(900, 600))
    scatter!(p, N_values, errors, label="Numerical contour calculation")
    display(p)

    velocities = collect(range(-2.0, 2.0, length=401))
    free_arrivals = x0 .+ T .* velocities
    linear_arrivals = free_arrivals .- F*T^2/(2*m)
    println("Free and linear arrival derivative = ", T)
    p = plot(velocities, free_arrivals, label="F = 0: free or constant",
        xlabel="Initial velocity v0", ylabel="Arrival position x(T)", size=(900, 600))
    plot!(p, velocities, linear_arrivals, label="F = 1: linear")
    display(p)
end

main()
