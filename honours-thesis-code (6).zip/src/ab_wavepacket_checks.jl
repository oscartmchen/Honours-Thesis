using FFTW
using FastGaussQuadrature
using SpecialFunctions
using Plots

function main()
    alpha = 0.3
    T     = 0.6
    L     = 12.0
    order = 96
    N_values = [16, 32, 64]
    comparison = collect(0.0:0.01:8.0)

    initial_packet(x) = 2/pi^(1/4) * x * exp(-(1-im)*x^2/2)

    function free_packet(x, t)
        d = 1 + im*(1-im)*t
        return 2/pi^(1/4) * x * d^(-3/2) * exp(-(1-im)*x^2/(2*d))
    end

    function packet_source(x, t, a, g, quadrature)
        if x == 0 || g == 0
            return 0.0im
        end
        lx, lw, hx, hw, gx, gw = quadrature
        d = 1 + im*(1-im)*t
        A = ((1-im)/d-im/a)/2
        rotation = exp(-im*angle(A)/2)/sqrt(abs(A))
        C0 = im*x^2/(2*a)
        h(z) = z*expm1(-im*a*g/(1+z)^2)

        function half_line(kappa)
            integral = 0.0im
            if abs(kappa)/sqrt(abs(A)) < 4
                for j in eachindex(gx)
                    v = 6*(gx[j]+1)
                    z = rotation*v
                    integral += 6*gw[j]*rotation*exp(-v^2-im*kappa*z+C0)*h(z)
                end
                return integral
            end
            sigma = sign(kappa)
            b = -im*kappa/(2*A)
            for j in eachindex(lx)
                W = sqrt(b^2+lx[j]/A)
                if real(W) < 0
                    W = -W
                end
                z = -sigma*lx[j]/A/(W+sigma*b)
                integral += lw[j]*(-sigma/(2*A*W))*h(z)
            end
            integral *= exp(C0)
            if kappa > 0
                saddle = sum(hw[j]*h(b+rotation*hx[j]) for j in eachindex(hx))
                integral += exp(C0+A*b^2)*rotation*saddle
            end
            return integral
        end

        return 2/pi^(1/4)*d^(-3/2)/sqrt(2*pi*im*a) *
               (half_line(x/a)-half_line(-x/a))
    end

    function free_packet_step(values, multiplier)
        N = length(values)-1
        extended = zeros(ComplexF64, 4*N)
        extended[2*N+1:3*N+1] .= values
        extended[N+1:2*N] .= -reverse(values[2:end])
        extended[N+1] /= 2
        extended[3*N+1] /= 2
        evolved = ifft(fft(extended) .* multiplier)
        result = evolved[2*N+1:3*N+1]
        result[1] = 0
        return result
    end

    function calculate_packet(ell, alpha, T, nmax, L, dx, order)
        local x, u
        N = round(Int, L/dx)
        x = collect(0:N) .* dx
        a = T/nmax
        g = ((ell-alpha)^2-1/4)/2
        V = g ./ (1 .+ x).^2
        w = exp.(-im*a .* V)
        k = 2*pi .* fftfreq(4*N, 1/dx)
        multiplier = exp.(-im*a .* k.^2/2)
        lx, lw = gausslaguerre(order)
        hx, hw = gausshermite(order)
        gx, gw = gausslegendre(order)
        quadrature = (lx, lw, hx, hw, gx, gw)
        remainder = expm1.(im*a .* V/2) .* initial_packet.(x)
        for j in 0:(nmax-1)
            source = [packet_source(q, j*a, a, g, quadrature) for q in x]
            remainder = source .+ free_packet_step(w .* remainder, multiplier)
        end
        u = exp.(-im*a .* V/2) .* (free_packet.(x, T) .+ remainder)
        u[1] = 0
        return x, u
    end

    function packet_reference(x, ell, alpha, T, kmax, order, dy)
        local reference
        nu = abs(ell-alpha)
        N = round(Int, 12/dy)
        y = collect(0:N) .* dy
        w = fill(dy/3, N+1)
        w[2:2:N] .= 4*dy/3
        w[3:2:N] .= 2*dy/3
        weighted_f = w .* initial_packet.(y)
        nodes, weights = gausslegendre(order)
        reference = zeros(ComplexF64, length(x))
        for left in 0.0:0.5:kmax-0.5
            for j in eachindex(nodes)
                if left == 0
                    s = (nodes[j]+1)/2
                    k = 0.5*s^2
                    wk = 0.5*s*weights[j]
                else
                    k = left+0.25*(nodes[j]+1)
                    wk = 0.25*weights[j]
                end
                J0 = besselj(nu, k)
                Y0 = bessely(nu, k)
                phi(q) = q == 0 ? 0.0 : sqrt(k*(1+q)) *
                    (Y0*besselj(nu, k*(1+q))-J0*bessely(nu, k*(1+q)))/hypot(J0, Y0)
                coefficient = sum(phi.(y) .* weighted_f)
                reference .+= wk*exp(-im*k^2*T/2)*coefficient .* phi.(x)
            end
        end
        return reference
    end

    function packet_integral(x, values)
        return sum((x[j+1]-x[j])*(values[j+1]+values[j])/2 for j in 1:(length(x)-1))
    end

    base_reference = [packet_reference(comparison, ell, alpha, T, 40.0, 24, 0.005) for ell in (0, 1)]
    reference = [packet_reference(comparison, ell, alpha, T, 60.0, 32, 0.0025) for ell in (0, 1)]
    reference_change = maximum(maximum(abs.(base_reference[j] .- reference[j])) for j in 1:2)
    println("Reference refinement change = ", reference_change)

    cases = [(16, 12.0, 0.002, 96), (32, 12.0, 0.002, 96),
        (64, 12.0, 0.001, 96), (32, 12.0, 0.001, 96),
        (32, 12.0, 0.002, 64), (32, 16.0, 0.001, 96)]
    solutions = []
    errors = zeros(3, 2)
    for (i, (nmax, L, dx, order)) in enumerate(cases)
        modes = []
        for (j, ell) in enumerate((0, 1))
            x, u = calculate_packet(ell, alpha, T, nmax, L, dx, order)
            sampled = u[round.(Int, comparison ./ dx) .+ 1]
            push!(modes, sampled)
            difference = sampled .- reference[j]
            l2_error = sqrt(packet_integral(comparison, abs2.(difference)))
            norm = packet_integral(x, abs2.(u))
            mean_radius = packet_integral(x, (1 .+ x) .* abs2.(u))/norm
            if i <= length(N_values)
                errors[i, j] = l2_error
            end
            println("ell = ", ell, ", N = ", nmax, ", L = ", L, ", dx = ", dx, ", order = ", order,
                ", maximum error = ", maximum(abs.(difference)),
                ", L2 complex error = ", l2_error, ", norm = ", norm,
                ", mean radius = ", mean_radius)
        end
        push!(solutions, modes)
    end

    for (label, a, b) in [("Spacing refinement change", 2, 4),
        ("Contour refinement change", 2, 5), ("Interval refinement change", 4, 6)]
        change = maximum(maximum(abs.(solutions[a][j] .- solutions[b][j])) for j in 1:2)
        println(label, " = ", change)
        if label == "Interval refinement change"
            println("Appendix C printed interval change = ", 2.20e-7)
            println("Difference from Appendix C printed interval change = ", change-2.20e-7)
        end
    end

    p = plot(N_values, errors[:, 1], xscale=:log10, yscale=:log10,
        marker=:circle, xlabel="N", ylabel="L2 complex error", label="ell = 0")
    plot!(p, N_values, errors[:, 2], marker=:circle, label="ell = 1")
    plot!(p, N_values, errors[1, 1] .* (N_values[1] ./ N_values).^2,
        linestyle=:dash, label="N^-2")
    display(p)
end

main()
