using FFTW
using FastGaussQuadrature
using QuadGK
using SpecialFunctions
using LinearAlgebra: Tridiagonal
using Plots

function main()
    m     = 1.0
    hbar  = 1.0
    Rc    = 1.0
    T     = 1.0
    x0    = 0.6
    x1    = 0.8
    nmax  = 16
    Qmax  = 48.0
    N     = 8192
    a     = T/nmax
    dQ    = 2*Qmax/N

    Q_fine = collect(range(-Qmax+dQ/2, step=dQ, length=N))
    Q_coarse = collect(-Qmax:1.0:Qmax)
    k = 2*pi .* fftfreq(N, 1/dQ)
    nodes, weights = gausslegendre(32)
    low_nodes, low_weights = gausslegendre(16)
    flow_steps = 32
    panel_width = 0.5
    flow_time = 0.7

    println("Normalized downward RK4 flow: ", flow_steps, " steps; duration ", flow_time, ", or 0.3 for N = 4 and nu >= 7.5")
    println("Flow normalization = sqrt(1+abs2(df)+curvature_bound^2); Gauss order ", length(nodes), ", panel width <= ", panel_width)

    V(x, nu) = hbar^2*(nu^2-1/4)/(2*m*(Rc+abs(x))^2)
    free_I(Q, n) = exp(im*m*(Q-x0)^2/(2*a*n*hbar))/sqrt(n)
    Jbar(Q, n, nu) = free_I(Q, n)*exp(-im*a/hbar *
        sum(V(x0+j*(Q-x0)/n, nu) for j in 1:(n-1); init=0.0))

    function phase(z, Q, n, nu, signs)
        g = hbar^2*(nu^2-1/4)/(2*m)
        potential = 0.0im
        derivative = 0.0im
        curvature = 0.0im
        for j in 1:(n-1)
            t = j/(n-1)
            q = Rc+signs[j]*(x0+t*(z-x0))
            potential += g/q^2
            derivative -= 2*g*signs[j]*t/q^3
            curvature += 6*g*t^2/q^4
        end
        S = (m*((z-x0)^2/(n-1)+(z-Q)^2)/(2*a)-a*potential)/hbar
        dS = (m*((z-x0)/(n-1)+z-Q)/a-a*derivative)/hbar
        ddS = (m*(1+1/(n-1))/a-a*curvature)/hbar
        return S, dS, ddS
    end

    function fixed_endpoint_flow(t, lower, upper, Q, n, nu, signs, duration)
        u = (2*t-lower-upper)/(upper-lower)
        w = 1-u^2
        dw = -4*u/(upper-lower)
        z = complex(t)
        jacobian = 1.0+0.0im
        dt = duration/flow_steps
        g = hbar^2*(nu^2-1/4)/(2*m)
        curvature_bound = m*(1+1/(n-1))/(a*hbar) +
            6*a*abs(g)*sum((j/(n-1))^2 for j in 1:(n-1))/(hbar*Rc^4)

        function velocity(z, jacobian)
            _, dS, ddS = phase(z, Q, n, nu, signs)
            df = im*dS
            ddf = im*ddS
            denominator = sqrt(1+abs2(df)+curvature_bound^2)
            derivative = real(conj(df)*ddf*jacobian)/denominator
            dz = -w*conj(df)/denominator
            dj = -dw*conj(df)/denominator-w*conj(ddf*jacobian)/denominator +
                 w*conj(df)*derivative/denominator^2
            return dz, dj
        end

        for j in 1:flow_steps
            k1, j1 = velocity(z, jacobian)
            k2, j2 = velocity(z+dt*k1/2, jacobian+dt*j1/2)
            k3, j3 = velocity(z+dt*k2/2, jacobian+dt*j2/2)
            k4, j4 = velocity(z+dt*k3, jacobian+dt*j3)
            z += dt*(k1+2*k2+2*k3+k4)/6
            jacobian += dt*(j1+2*j2+2*j3+j4)/6
        end
        return z, jacobian
    end

    function contour(Q, n, nu)
        local Z = ComplexF64[]
        local W = ComplexF64[]
        controls = [-0.5, -0.25, 0.0, 0.25, 0.5]

        function rule(curve, lower, upper, signs, qnodes, qweights)
            zvalues = ComplexF64[]
            wvalues = ComplexF64[]
            values = zeros(ComplexF64, length(controls))
            for j in eachindex(qnodes)
                t = (lower+upper)/2+(upper-lower)*qnodes[j]/2
                z, dz = curve(t)
                value = (upper-lower)*qweights[j]/2*dz*exp(im*phase(z, Q, n, nu, signs)[1])
                push!(zvalues, z)
                push!(wvalues, value)
                values .+= value .* exp.(im*m/(2*a*hbar) .* (controls.^2 .- 2 .* (z-Q) .* controls))
            end
            return zvalues, wvalues, values
        end

        function add_panel(curve, lower, upper, signs, budget, depth)
            _, _, low = rule(curve, lower, upper, signs, low_nodes, low_weights)
            zvalues, wvalues, high = rule(curve, lower, upper, signs, nodes, weights)
            if maximum(abs.(high .- low)) <= budget+1e-11*maximum(abs.(high))
                append!(Z, zvalues)
                append!(W, wvalues)
            else
                if depth == 24
                    error("Contour quadrature did not converge")
                end
                midpoint = (lower+upper)/2
                add_panel(curve, lower, midpoint, signs, budget/2, depth+1)
                add_panel(curve, midpoint, upper, signs, budget/2, depth+1)
            end
        end

        function add_curve(curve, lower, upper, signs, budget)
            panels = max(1, ceil(Int, (upper-lower)/panel_width))
            for j in 1:panels
                lo = lower+(j-1)*(upper-lower)/panels
                hi = lower+j*(upper-lower)/panels
                add_panel(curve, lo, hi, signs, budget/panels, 0)
            end
        end

        splits = sort(unique([x0*(1-(n-1)/j) for j in 1:(n-1)]))
        saddle = (x0+(n-1)*Q)/n
        left = min(first(splits), saddle)
        right = max(last(splits), saddle)
        boundaries = sort(unique(vcat(left, splits, right)))
        budget = 1e-12/(length(boundaries)+1)
        duration = nmax == 4 && nu >= 7.5 ? 0.3 : flow_time
        for j in 1:(length(boundaries)-1)
            lower, upper = boundaries[j], boundaries[j+1]
            signs = [x0+r*((lower+upper)/2-x0)/(n-1)<0 ? -1.0 : 1.0 for r in 1:(n-1)]
            curve(t) = fixed_endpoint_flow(t, lower, upper, Q, n, nu, signs, duration)
            add_curve(curve, lower, upper, signs, budget)
        end
        scale = sqrt(m*n/(2*a*hbar*(n-1)))
        rotation = exp(im*pi/4)
        for (pivot, direction) in ((left, -1), (right, 1))
            signs = [x0+j*(pivot+direction-x0)/(n-1)<0 ? -1.0 : 1.0 for j in 1:(n-1)]
            ray(t) = (pivot+direction*rotation*t/scale, rotation/scale)
            add_curve(ray, 0.0, 12.0, signs, budget)
        end
        W .*= sqrt(m/(2*pi*im*hbar*a*(n-1)))
        keep = abs.(W) .* exp.(m .* abs.(imag.(Z))/(2*a*hbar)) .> 1e-12/length(W)
        return Z[keep], W[keep]
    end

    function calculate_J(n, nu)
        J = zeros(ComplexF64, N)
        for Q in Q_coarse
            indices = findall(abs.(Q_fine .- Q) .<= 0.5)
            if isempty(indices)
                continue
            end
            Z, W = contour(Q, n, nu)
            for j in indices
                delta = Q_fine[j]-Q
                J[j] = sum(W .* exp.(im*m/(2*a*hbar) .* (delta^2 .- 2 .* (Z .- Q) .* delta)))
            end
        end
        return J
    end

    function calculate_G(nu)
        I = free_I.(Q_fine, 1) .- reverse(free_I.(Q_fine, 1))
        for n in 2:nmax
            println("nu = ", nu, ", n = ", n)
            flush(stdout)
            background = Jbar.(Q_fine, n-1, nu)
            J = calculate_J(n, nu)
            delta_I = I .- (background .- reverse(background))
            correction = ifft(fft(delta_I .* exp.(-im*a .* V.(Q_fine, nu)/hbar)) .* 
                exp.(-im*a*hbar .* k.^2/(2*m)))
            I = J .- reverse(J) .+ correction
            I = (I .- reverse(I))/2
        end
        return sqrt(m/(2*pi*im*hbar*a)) .* I .* 
            exp.(-im*a .* (V(x0, nu) .+ V.(Q_fine, nu))/(2*hbar))
    end

    function sample(G)
        curvature = zeros(ComplexF64, N)
        curvature[2:end-1] = Tridiagonal(ones(N-3), fill(4.0, N-2), ones(N-3)) \
            (6 .* (G[1:end-2] .- 2 .* G[2:end-1] .+ G[3:end])/dQ^2)
        j = searchsortedlast(Q_fine, x1)
        A = (Q_fine[j+1]-x1)/dQ
        B = 1-A
        return A*G[j]+B*G[j+1]+dQ^2 *
            ((A^3-A)*curvature[j]+(B^3-B)*curvature[j+1])/6
    end

    function reference(nu)
        function integrand(t)
            q = exp(-0.04im)*t
            J = besselj(nu, q*Rc)
            Y = bessely(nu, q*Rc)
            f(x) = Y*besselj(nu, q*(Rc+x))-J*bessely(nu, q*(Rc+x))
            return exp(-0.04im)*q*sqrt((Rc+x1)*(Rc+x0))*f(x1)*f(x0)/(J^2+Y^2) *
                exp(-im*hbar*q^2*T/(2*m))
        end
        value, error = quadgk(integrand, collect(0.0:0.5:40.0)...; rtol=1e-10, atol=1e-12)
        return value
    end

    function shadow(modes, amplitudes)
        value = 0.0im
        for i in eachindex(modes), j in eachindex(modes)
            d = modes[i]-modes[j]
            weight = d == 0 ? pi/8 : 2*sinpi(d/16)/d
            value += amplitudes[i]*conj(amplitudes[j])*cospi(d)*weight
        end
        return real(value)
    end

    integral(values) = sum(values)-(first(values)+last(values))/2
    shadows = Float64[]
    shadow_references = Float64[]

    theta = collect(range(-pi, pi, length=401))
    c = 1/(2*pi*sqrt((Rc+x1)*(Rc+x0)))
    alpha_values = [0.0, 0.37, 0.5]
    profiles = []
    reference_profiles = []
    for alpha in alpha_values
        modes = alpha == 0.5 ? collect(-9:10) : collect(-9:9)
        orders = unique(abs.(modes .- alpha))
        amplitudes = [sample(calculate_G(nu)) for nu in orders]
        coefficients = [amplitudes[argmin(abs.(orders .- abs(ell-alpha)))] for ell in modes]
        G = [c*sum(coefficients .* exp.(im .* modes .* angle)) for angle in theta]
        reference_modes = alpha == 0.5 ? collect(-20:21) : collect(-20:20)
        exact = [reference(abs(ell-alpha)) for ell in reference_modes]
        Gref = [c*sum(exact .* exp.(im .* reference_modes .* angle)) for angle in theta]
        error = G .- Gref
        println("alpha = ", alpha, ", mean complex error = ", integral(abs.(error))/(length(theta)-1))
        println("Relative RMS error = ", sqrt(integral(abs2.(error))/integral(abs2.(Gref))))
        println("Antipodal amplitudes = ", G[end], ", ", Gref[end])
        if alpha != 0.5
            println("Antipodal intensity error = ", abs(abs2(G[end])/abs2(Gref[end])-1))
        end
        push!(shadows, shadow(modes, coefficients))
        push!(shadow_references, shadow(reference_modes, exact))
        push!(profiles, G)
        push!(reference_profiles, Gref)
    end
    println("Half-flux shadow ratio = ", shadows[3]/shadows[1])
    println("Reference shadow ratio = ", shadow_references[3]/shadow_references[1])
    normalization = abs2(reference_profiles[1][end])
    shadow_count = div(length(theta)-1, 8)
    shadow_indices = vcat(collect((length(theta)-shadow_count):length(theta)),
        collect(2:(shadow_count+1)))
    shadow_angles = collect(range(-pi/4, pi/4, length=length(shadow_indices)))
    colors = [:royalblue, :seagreen, :purple]
    figure = plot(layout=(1, 2), size=(1100, 450),
        left_margin=7Plots.mm, bottom_margin=7Plots.mm)
    for j in eachindex(alpha_values)
        plot!(figure, theta, abs2.(profiles[j])/normalization,
            subplot=1, color=colors[j], label="alpha = $(alpha_values[j])",
            xlabel="Angular displacement theta", ylabel="|G|²/|G0,ref(pi)|²",
            title="(a) Full angular profile", xlims=(-pi, pi))
        plot!(figure, theta, abs2.(reference_profiles[j])/normalization,
            subplot=1, color=colors[j], linestyle=:dash, label="")
        plot!(figure, shadow_angles, abs2.(profiles[j][shadow_indices])/normalization,
            subplot=2, color=colors[j], label=j==1 ? "Stitching, N = $nmax" : "",
            xlabel="Offset from antipode theta - pi", title="(b) Shadow region",
            xlims=(-pi/4, pi/4))
        plot!(figure, shadow_angles, abs2.(reference_profiles[j][shadow_indices])/normalization,
            subplot=2, color=colors[j], linestyle=:dash,
            label=j==1 ? "Continuum reference" : "")
    end
    display(figure)
end

main()
