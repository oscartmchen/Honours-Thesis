using FFTW
using FastGaussQuadrature
using QuadGK
using SpecialFunctions
using LinearAlgebra: Tridiagonal

function main()
    m     = 1.0
    hbar  = 1.0
    Rc    = 1.0
    T     = 1.0
    x0    = 0.6
    x1    = 0.8
    flow_steps = 32
    panel_width = 0.5
    flow_time = 0.7
    nodes, weights = gausslegendre(32)
    low_nodes, low_weights = gausslegendre(16)

    println("Normalized downward RK4 flow: ", flow_steps, " steps; duration ", flow_time, ", or 0.3 for N = 4 and nu >= 7.5")
    println("Flow normalization = sqrt(1+abs2(df)+curvature_bound^2); Gauss order ", length(nodes), ", panel width <= ", panel_width)

    V(x, nu) = hbar^2*(nu^2-1/4)/(2*m*(Rc+abs(x))^2)
    free_I(Q, n, a) = exp(im*m*(Q-x0)^2/(2*a*n*hbar))/sqrt(n)
    Jbar(Q, n, nu, a) = free_I(Q, n, a)*exp(-im*a/hbar *
        sum(V(x0+j*(Q-x0)/n, nu) for j in 1:(n-1); init=0.0))

    function phase(z, Q, n, nu, signs, a)
        g = hbar^2*(nu^2-1/4)/(2*m)
        potential = 0.0im
        derivative = 0.0im
        curvature = 0.0im
        for j in 1:(n-1)
            t = j/(n-1)
            q = Rc+signs[j]*(x0+t*(z-x0))
            potential += g/q^2
            derivative -= 2*g*signs[j]*t/q^3
            curvature += 6*g*t^2/q^4
        end
        S = (m*((z-x0)^2/(n-1)+(z-Q)^2)/(2*a)-a*potential)/hbar
        dS = (m*((z-x0)/(n-1)+z-Q)/a-a*derivative)/hbar
        ddS = (m*(1+1/(n-1))/a-a*curvature)/hbar
        return S, dS, ddS
    end

    function fixed_endpoint_flow(t, lower, upper, Q, n, nu, signs, duration, a)
        u = (2*t-lower-upper)/(upper-lower)
        w = 1-u^2
        dw = -4*u/(upper-lower)
        z = complex(t)
        jacobian = 1.0+0.0im
        dt = duration/flow_steps
        g = hbar^2*(nu^2-1/4)/(2*m)
        curvature_bound = m*(1+1/(n-1))/(a*hbar) +
            6*a*abs(g)*sum((j/(n-1))^2 for j in 1:(n-1))/(hbar*Rc^4)

        function velocity(z, jacobian)
            _, dS, ddS = phase(z, Q, n, nu, signs, a)
            df = im*dS
            ddf = im*ddS
            denominator = sqrt(1+abs2(df)+curvature_bound^2)
            derivative = real(conj(df)*ddf*jacobian)/denominator
            dz = -w*conj(df)/denominator
            dj = -dw*conj(df)/denominator-w*conj(ddf*jacobian)/denominator +
                 w*conj(df)*derivative/denominator^2
            return dz, dj
        end

        for j in 1:flow_steps
            k1, j1 = velocity(z, jacobian)
            k2, j2 = velocity(z+dt*k1/2, jacobian+dt*j1/2)
            k3, j3 = velocity(z+dt*k2/2, jacobian+dt*j2/2)
            k4, j4 = velocity(z+dt*k3, jacobian+dt*j3)
            z += dt*(k1+2*k2+2*k3+k4)/6
            jacobian += dt*(j1+2*j2+2*j3+j4)/6
        end
        return z, jacobian
    end

    function contour(Q, n, nu, a, nmax)
        local Z = ComplexF64[]
        local W = ComplexF64[]
        controls = [-0.5, -0.25, 0.0, 0.25, 0.5]

        function rule(curve, lower, upper, signs, qnodes, qweights)
            zvalues = ComplexF64[]
            wvalues = ComplexF64[]
            values = zeros(ComplexF64, length(controls))
            for j in eachindex(qnodes)
                t = (lower+upper)/2+(upper-lower)*qnodes[j]/2
                z, dz = curve(t)
                value = (upper-lower)*qweights[j]/2*dz*exp(im*phase(z, Q, n, nu, signs, a)[1])
                push!(zvalues, z)
                push!(wvalues, value)
                values .+= value .* exp.(im*m/(2*a*hbar) .* (controls.^2 .- 2 .* (z-Q) .* controls))
            end
            return zvalues, wvalues, values
        end

        function add_panel(curve, lower, upper, signs, budget, depth)
            _, _, low = rule(curve, lower, upper, signs, low_nodes, low_weights)
            zvalues, wvalues, high = rule(curve, lower, upper, signs, nodes, weights)
            if maximum(abs.(high .- low)) <= budget+1e-11*maximum(abs.(high))
                append!(Z, zvalues)
                append!(W, wvalues)
            else
                if depth == 24
                    error("Contour quadrature did not converge")
                end
                midpoint = (lower+upper)/2
                add_panel(curve, lower, midpoint, signs, budget/2, depth+1)
                add_panel(curve, midpoint, upper, signs, budget/2, depth+1)
            end
        end

        function add_curve(curve, lower, upper, signs, budget)
            panels = max(1, ceil(Int, (upper-lower)/panel_width))
            for j in 1:panels
                lo = lower+(j-1)*(upper-lower)/panels
                hi = lower+j*(upper-lower)/panels
                add_panel(curve, lo, hi, signs, budget/panels, 0)
            end
        end

        splits = sort(unique([x0*(1-(n-1)/j) for j in 1:(n-1)]))
        saddle = (x0+(n-1)*Q)/n
        left = min(first(splits), saddle)
        right = max(last(splits), saddle)
        boundaries = sort(unique(vcat(left, splits, right)))
        budget = 1e-12/(length(boundaries)+1)
        duration = nmax == 4 && nu >= 7.5 ? 0.3 : flow_time
        for j in 1:(length(boundaries)-1)
            lower, upper = boundaries[j], boundaries[j+1]
            signs = [x0+r*((lower+upper)/2-x0)/(n-1)<0 ? -1.0 : 1.0 for r in 1:(n-1)]
            curve(t) = fixed_endpoint_flow(t, lower, upper, Q, n, nu, signs, duration, a)
            add_curve(curve, lower, upper, signs, budget)
        end
        scale = sqrt(m*n/(2*a*hbar*(n-1)))
        rotation = exp(im*pi/4)
        for (pivot, direction) in ((left, -1), (right, 1))
            signs = [x0+j*(pivot+direction-x0)/(n-1)<0 ? -1.0 : 1.0 for j in 1:(n-1)]
            ray(t) = (pivot+direction*rotation*t/scale, rotation/scale)
            add_curve(ray, 0.0, 12.0, signs, budget)
        end
        W .*= sqrt(m/(2*pi*im*hbar*a*(n-1)))
        keep = abs.(W) .* exp.(m .* abs.(imag.(Z))/(2*a*hbar)) .> 1e-12/length(W)
        return Z[keep], W[keep]
    end

    function calculate_J(n, nu, a, nmax, Q_fine, Q_coarse)
        J = zeros(ComplexF64, length(Q_fine))
        for Q in Q_coarse
            indices = findall(abs.(Q_fine .- Q) .<= 0.5)
            if isempty(indices)
                continue
            end
            Z, W = contour(Q, n, nu, a, nmax)
            for j in indices
                delta = Q_fine[j]-Q
                J[j] = sum(W .* exp.(im*m/(2*a*hbar) .* (delta^2 .- 2 .* (Z .- Q) .* delta)))
            end
        end
        return J
    end

    function calculate_G(nu, nmax, Qmax, N)
        a = T/nmax
        dQ = 2*Qmax/N
        Q_fine = collect(range(-Qmax+dQ/2, step=dQ, length=N))
        Q_coarse = collect(-Qmax:1.0:Qmax)
        k = 2*pi .* fftfreq(N, 1/dQ)
        I = free_I.(Q_fine, 1, a) .- reverse(free_I.(Q_fine, 1, a))
        for n in 2:nmax
            println("nu = ", nu, ", n = ", n)
            flush(stdout)
            background = Jbar.(Q_fine, n-1, nu, a)
            J = calculate_J(n, nu, a, nmax, Q_fine, Q_coarse)
            delta_I = I .- (background .- reverse(background))
            correction = ifft(fft(delta_I .* exp.(-im*a .* V.(Q_fine, nu)/hbar)) .* 
                exp.(-im*a*hbar .* k.^2/(2*m)))
            I = J .- reverse(J) .+ correction
            I = (I .- reverse(I))/2
        end
        G = sqrt(m/(2*pi*im*hbar*a)) .* I .* 
            exp.(-im*a .* (V(x0, nu) .+ V.(Q_fine, nu))/(2*hbar))
        return Q_fine, G
    end

    function sample(Q_fine, G)
        N = length(Q_fine)
        dQ = Q_fine[2]-Q_fine[1]
        curvature = zeros(ComplexF64, N)
        curvature[2:end-1] = Tridiagonal(ones(N-3), fill(4.0, N-2), ones(N-3)) \
            (6 .* (G[1:end-2] .- 2 .* G[2:end-1] .+ G[3:end])/dQ^2)
        j = searchsortedlast(Q_fine, x1)
        A = (Q_fine[j+1]-x1)/dQ
        B = 1-A
        return A*G[j]+B*G[j+1]+dQ^2 *
            ((A^3-A)*curvature[j]+(B^3-B)*curvature[j+1])/6
    end

    function reference(nu, rtol, cutoff)
        function integrand(t)
            q = exp(-0.04im)*t
            J = besselj(nu, q*Rc)
            Y = bessely(nu, q*Rc)
            f(x) = Y*besselj(nu, q*(Rc+x))-J*bessely(nu, q*(Rc+x))
            return exp(-0.04im)*q*sqrt((Rc+x1)*(Rc+x0))*f(x1)*f(x0)/(J^2+Y^2) *
                exp(-im*hbar*q^2*T/(2*m))
        end
        value, error = quadgk(integrand, collect(0.0:0.5:cutoff)...; rtol=rtol, atol=rtol/100)
        return value
    end

    function reference_background(Q, n, nu, a, R, order)
        mu = (x0+(n-1)*Q)/n
        A = m*n/(2*a*hbar*(n-1))
        g = hbar^2*(nu^2-1/4)/(2*m)
        b = a/hbar
        local nodes, weights = gausslegendre(order)
        function residual(u)
            z = mu+u
            potential = 0.0
            for j in 1:(n-1)
                q = x0+j*(z-x0)/(n-1)
                potential += g/(Rc+abs(q))^2
            end
            return expm1(-im*b*potential)
        end
        function tail(direction)
            z = mu+direction*R
            potential = 0.0
            derivative = 0.0
            curvature = 0.0
            third = 0.0
            for j in 1:(n-1)
                t = j/(n-1)
                q = x0+t*(z-x0)
                d = Rc+abs(q)
                potential += g/d^2
                derivative -= 2*g*sign(q)*t*direction/d^3
                curvature += 6*g*t^2/d^4
                third -= 24*g*sign(q)*t^3*direction/d^5
            end
            e = exp(-im*b*potential)
            f = expm1(-im*b*potential)
            fp = -im*b*derivative*e
            fpp = (-im*b*curvature-b^2*derivative^2)*e
            fppp = (-im*b*third-3*b^2*derivative*curvature+im*b^3*derivative^3)*e
            F1 = (fp/R-f/R^2)/(2im*A)
            F2 = (fpp/R^2-3*fp/R^3+3*f/R^4)/(2im*A)^2
            F3 = (fppp/R^3-6*fpp/R^4+15*fp/R^5-15*f/R^6)/(2im*A)^3
            return -exp(im*A*R^2)*(f-F1+F2-F3)/(2im*A*R)
        end
        steps = ceil(Int, A*R^2/pi)
        positive = sqrt.(min.(collect(0:steps) .* pi/A, R^2))
        splits = [x0*(1-(n-1)/j)-mu for j in 1:(n-1)]
        boundaries = sort(unique(vcat(-reverse(positive),positive,splits)))
        value = 0.0im
        correction = 0.0im
        for k in 1:(length(boundaries)-1)
            lower, upper = boundaries[k], boundaries[k+1]
            if lower < -R || upper > R
                continue
            end
            midpoint = (lower+upper)/2
            halfwidth = (upper-lower)/2
            part = 0.0im
            for j in eachindex(nodes)
                u = midpoint+halfwidth*nodes[j]
                part += weights[j]*exp(im*A*u^2)*residual(u)
            end
            part *= halfwidth
            increment = part-correction
            next = value+increment
            correction = (next-value)-increment
            value = next
        end
        value += tail(1)+tail(-1)
        return exp(im*m*(Q-x0)^2/(2*a*n*hbar))/sqrt(n)*(1+sqrt(A/(pi*im))*value)
    end

    theta = collect(range(-pi, pi, length=401))
    c = 1/(2*pi*sqrt((Rc+x1)*(Rc+x0)))
    alpha = 0.37
    modes = collect(-9:9)

    function profile(nmax, Qmax, N)
        coefficients = ComplexF64[]
        for ell in modes
            Q_fine, G = calculate_G(abs(ell-alpha), nmax, Qmax, N)
            push!(coefficients, sample(Q_fine, G))
        end
        return [c*sum(coefficients .* exp.(im .* modes .* angle)) for angle in theta]
    end

    maximum_background_error = 0.0
    maximum_reference_refinement = 0.0
    count = 0
    for n in (2, 4, 8, 16), nu in (0.37, 1.37, 2.5, 5.5, 9.37), Q in (-2.0, -0.8, -0.2, 0.2, 0.8, 2.0)
        Z, W = contour(Q, n, nu, T/16, 16)
        coarse = reference_background(Q, n, nu, T/16, 100.0, 16)
        refined = reference_background(Q, n, nu, T/16, 150.0, 24)
        maximum_reference_refinement = max(maximum_reference_refinement, abs(refined-coarse))
        difference = abs(sum(W)-refined)
        maximum_background_error = max(maximum_background_error, difference)
        count += 1
    end
    println("Real-axis background comparisons = ", count, ", maximum difference = ", maximum_background_error)
    println("Real-axis reference refinement = ", maximum_reference_refinement)

    maximum_reference_change = 0.0
    for nu in (0.37, 1.37, 2.5, 5.5, 9.37)
        difference = abs(reference(nu, 1e-9, 40.0)-reference(nu, 1e-11, 40.0))
        maximum_reference_change = max(maximum_reference_change, difference)
    end
    println("Reference tolerance change = ", maximum_reference_change)

    reference_modes = collect(-24:24)
    references = [reference(abs(ell-alpha), 1e-11, 40.0) for ell in reference_modes]
    keep = abs.(reference_modes) .<= 20
    G_reference = [c*sum(references[keep] .* exp.(im .* reference_modes[keep] .* angle)) for angle in theta]
    G_refined = [c*sum(references .* exp.(im .* reference_modes .* angle)) for angle in theta]
    println("Angular reference cutoff 20 to 24, maximum change = ", maximum(abs.(G_refined .- G_reference)))

    integral(values) = sum(values)-(first(values)+last(values))/2
    G_final = ComplexF64[]
    for nmax in (4, 8, 16)
        G = profile(nmax, 48.0, 8192)
        difference = G .- G_reference
        println("N = ", nmax, ", mean complex error = ", integral(abs.(difference))/(length(theta)-1))
        println("Relative RMS error = ", sqrt(integral(abs2.(difference))/integral(abs2.(G_reference))))
        println("Antipodal intensity error = ", abs(abs2(G[end])/abs2(G_reference[end])-1))
        if nmax == 16
            G_final = G
        end
    end
    G_wide = profile(16, 96.0, 16384)
    G_fine = profile(16, 48.0, 16384)
    println("Radial interval change = ", maximum(abs.(G_wide .- G_final)))
    println("Radial spacing change = ", maximum(abs.(G_fine .- G_final)))
end

main()
