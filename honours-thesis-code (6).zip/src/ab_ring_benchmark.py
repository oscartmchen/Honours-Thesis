import os

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

import platform
import time
import numpy as np

I       = 1.0
hbar    = 1.0
T       = 1.0
epsilon = 0.05
z       = T - 1j*epsilon

alpha_values = np.linspace(0.0, 1.0, 201)
theta_values = np.array([0.7, np.pi])
nmax  = 16
order = 32
wmax  = 3
lmax  = 20
M     = 4096
runs  = 11
target = 1e-4


def winding_setup():
    displacements = theta_values[:, None] + 2*np.pi*np.arange(-wmax, wmax+1)
    phases = np.sqrt(I/(2*np.pi*1j*hbar*z))*np.exp(
        1j*I*displacements**2/(2*hbar*z))
    return displacements, phases


def winding_evaluate(setup):
    displacements, phases = setup
    return np.sum(phases[:, None, :]*np.exp(
        1j*alpha_values[None, :, None]*displacements[:, None, :]), axis=2)


def spectral_setup(cutoff):
    modes = np.arange(-cutoff, cutoff+1)
    phases = np.exp(1j*theta_values[:, None]*modes)
    return modes, phases


def spectral_evaluate(setup):
    modes, phases = setup
    evolution = np.exp(-1j*hbar*z*(modes[None, :]-alpha_values[:, None])**2/(2*I))
    return phases @ evolution.T/(2*np.pi)


def contour_setup():
    displacements, phases = winding_setup()
    nodes, weights = np.polynomial.legendre.leggauss(order)
    gaussian = np.dot(8*weights, np.exp(-(8*nodes)**2))
    a = z/nmax
    rotation = np.exp(1j*(np.pi/4 + np.angle(z)/2))
    prefactor = (I/(2*np.pi*1j*hbar*a))**(nmax/2)
    for j in range(1, nmax):
        eigenvalue = 4*np.sin(j*np.pi/(2*nmax))**2
        coefficient = I*eigenvalue/(2*hbar*a)
        prefactor *= rotation*gaussian/np.sqrt(abs(coefficient))
    phases *= prefactor/np.sqrt(I/(2*np.pi*1j*hbar*z))
    return displacements, phases


def difference_setup():
    modes = np.arange(-M//2, M//2)
    phases = np.exp(1j*theta_values[:, None]*modes)
    return modes, phases, 2*np.pi/M


def difference_evaluate(setup):
    modes, phases, spacing = setup
    energies = 2*hbar**2*np.sin(
        (modes[None, :]-alpha_values[:, None])*spacing/2)**2/(I*spacing**2)
    return phases @ np.exp(-1j*z*energies/hbar).T/(2*np.pi)


def measure(action):
    measurements = []
    for j in range(runs):
        start = time.perf_counter()
        action()
        measurements.append(time.perf_counter()-start)
    return 1000*np.median(measurements)


reference = spectral_evaluate(spectral_setup(80))
refined = spectral_evaluate(spectral_setup(100))
print("Report software: Python 3.12.14; NumPy 2.3.5")
print("Python", platform.python_version(), "; NumPy", np.__version__)
print("Machine =", platform.machine())
print("OPENBLAS_NUM_THREADS =", os.environ["OPENBLAS_NUM_THREADS"])
print("MKL_NUM_THREADS =", os.environ["MKL_NUM_THREADS"])
print("OMP_NUM_THREADS =", os.environ["OMP_NUM_THREADS"])
print("I =", I, "; hbar =", hbar, "; T =", T, "; epsilon =", epsilon, "; N =", nmax)
print("Outputs =", len(alpha_values)*len(theta_values), "; flux values =", len(alpha_values))
print("Maximum absolute error target =", target)
print("Times are medians of", runs, "runs after untimed setup and evaluation.")
print("Startup, reference construction and file I/O are excluded.")
print("Total includes setup; reuse caches only flux-independent setup.")
print("Timings below are new measurements, not recovered historical measurements.")
print("Reference refinement =", np.max(np.abs(refined-reference)))

methods = [
    ("Exact winding", f"|w| <= {wmax}", winding_setup, winding_evaluate),
    ("Spectral sum", f"|l| <= {lmax}", lambda: spectral_setup(lmax), spectral_evaluate),
    ("Gaussian contour", f"Q = {order}, |w| <= {wmax}", contour_setup, winding_evaluate),
    ("Finite difference", f"M = {M}", difference_setup, difference_evaluate),
]

print(f"{'Method':20} {'Settings':24} {'Max. error':>14} {'Total/ms':>14} {'Reuse/ms':>14}")
for name, settings, setup, evaluate in methods:
    cached = setup()
    output = evaluate(cached)
    evaluate(setup())
    error = np.max(np.abs(output-reference))
    if error > target:
        raise RuntimeError("The accuracy target was not reached for "+name)
    total = measure(lambda: evaluate(setup()))
    reuse = measure(lambda: evaluate(cached))
    print(f"{name:20} {settings:24} {error:14.6e} {total:14.6f} {reuse:14.6f}")
