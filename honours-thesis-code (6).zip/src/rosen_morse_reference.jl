using HypergeometricFunctions
using SpecialFunctions
using QuadGK
using Plots

function main()
    m     = 1.0
    hbar  = 0.25
    V0    = 1.0
    alpha = 1.0
    s     = -1
    x0    = 0.0
    T     = 10.0
    theta = 0.04
    kmax  = 40.0

    function rm_lambda()
        return -0.5 + sqrt(complex(0.25-2*m*s*V0/(hbar^2*alpha^2)))
    end

    function rm_outgoing(x, k)
        lambda = rm_lambda()
        z = (1-tanh(alpha*x))/2
        return exp(im*k*x)*pFq((-lambda, lambda+1), (1-im*k/alpha,), z)
    end

    function rm_coefficients(k)
        lambda = rm_lambda()
        q = k/alpha
        common = im*q*log(2)+log(pi)/2+loggamma(1-im*q)
        a = exp(common-loggamma((1-lambda-im*q)/2)-loggamma((2+lambda-im*q)/2))
        b = -2*alpha*exp(common-loggamma((-lambda-im*q)/2)-loggamma((1+lambda-im*q)/2))
        return a, b
    end

    function rm_parity(x, k)
        if abs(alpha*x) > 2.5
            f = rm_outgoing(abs(x), k)
            fm = rm_outgoing(abs(x), -k)
            a, b = rm_coefficients(k)
            am, bm = rm_coefficients(-k)
            C = (bm*f-b*fm)/(-2*im*k)
            S = (a*fm-am*f)/(-2*im*k)
            if x < 0
                return C, -S
            end
            return C, S
        end
        lambda = rm_lambda()
        q = k/alpha
        y = tanh(alpha*x)
        factor = exp(-im*q*log1p(-y*y)/2)
        C = factor*pFq(((-lambda-im*q)/2, (lambda+1-im*q)/2), (0.5,), y*y)
        S = y/alpha*factor*pFq(((1-lambda-im*q)/2, (lambda+2-im*q)/2), (1.5,), y*y)
        return C, S
    end

    function rm_continuum(x1, theta, kmax, rtol, atol)
        if V0 == 0
            return sqrt(m/(2*pi*im*hbar*T))*exp(im*m*(x1-x0)^2/(2*hbar*T))
        end
        function integrand(r)
            k = exp(-im*theta)*r
            C1, S1 = rm_parity(x1, k)
            C0, S0 = rm_parity(x0, k)
            a, b = rm_coefficients(k)
            am, bm = rm_coefficients(-k)
            density = k^2/pi*(C1*C0/(b*bm)+S1*S0/(a*am))
            return exp(-im*theta)*density*exp(-im*hbar*k^2*T/(2*m))
        end
        value, error = quadgk(integrand, 0.0, kmax; rtol=rtol, atol=atol)
        return value
    end

    function rm_state(n, x)
        lambda = real(rm_lambda())
        b = lambda-n
        if isodd(n) && x == 0
            return 0.0
        end
        z = (1-tanh(alpha*abs(x)))/2
        term = 1.0
        polynomial = 1.0
        for j in 1:n
            term *= (-n+j-1)*(n+2*b+j)*z/((b+j)*j)
            polynomial += term
        end
        polynomial *= exp(loggamma(n+b+1)-loggamma(n+1)-loggamma(b+1))
        lognorm = (log(alpha*b)+loggamma(n+1)+loggamma(n+2*b+1)-
                   2*b*log(2)-2*loggamma(n+b+1))/2
        value = exp(lognorm-b*log(cosh(alpha*x)))*polynomial
        if x < 0 && isodd(n)
            return -value
        end
        return value
    end

    function rm_bound(x1)
        if s == 1
            return 0.0im
        end
        lambda = real(rm_lambda())
        value = 0.0im
        for n in 0:(ceil(Int, lambda)-1)
            E = -hbar^2*alpha^2*(lambda-n)^2/(2*m)
            value += rm_state(n, x1)*rm_state(n, x0)*exp(-im*E*T/hbar)
        end
        return value
    end

    rm_reference(x1, theta, kmax, rtol, atol) = rm_continuum(x1, theta, kmax, rtol, atol)+rm_bound(x1)

    x1 = collect(range(-8.0, 8.0, length=129))
    G_cont = [rm_continuum(q, theta, kmax, 1e-10, 1e-11) for q in x1]
    G_bound = rm_bound.(x1)
    G = G_cont .+ G_bound

    println("Central bound intensity = ", abs2(rm_bound(0.0)))
    println("Central continuum intensity = ", abs2(rm_continuum(0.0, theta, kmax, 1e-10, 1e-11)))
    println("Central total intensity = ", abs2(rm_reference(0.0, theta, kmax, 1e-10, 1e-11)))
    checkpoints = [-4.0, 0.0, 4.0]
    G_control = [rm_reference(q, 0.04, 40.0, 1e-10, 1e-11) for q in checkpoints]
    G_refined = [rm_reference(q, 0.06, 48.0, 1e-12, 1e-13) for q in checkpoints]
    println("Float64 spectral reference refinement at ", checkpoints, " = ", maximum(abs.(G_control .- G_refined)))
    interference = 2 .* real.(G_bound .* conj.(G_cont))
    p = plot(layout=(1, 2), size=(1100, 450))
    plot!(p, x1, abs2.(G), subplot=1, label="Total", xlabel="x1", ylabel="Squared amplitude")
    plot!(p, x1, abs2.(G_bound), subplot=1, label="Bound")
    plot!(p, x1, abs2.(G_cont), subplot=1, label="Continuum")
    plot!(p, x1, interference, subplot=2, label="Bound-continuum interference", xlabel="x1", ylabel="2 Re(Gb Gc*)")
    display(p)
end

main()
