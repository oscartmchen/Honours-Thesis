using FFTW
using HypergeometricFunctions
using SpecialFunctions
using QuadGK
using Plots

function main()
    m     = 1.0
    hbar  = 1.0
    V0    = 1.0
    alpha = 1.0
    x0    = 0.0
    T     = 5.0
    theta = 0.04
    smax  = 6.0

    N_values = [5, 10, 20, 40]
    L = 120.0
    dQ = 0.05

    function ws_incident(k, p)
        return exp(loggamma(1-im*p/alpha)+loggamma(-im*k/alpha)-
                   loggamma(-im*(k+p)/(2*alpha))-loggamma(1-im*(k+p)/(2*alpha)))
    end

    function ws_outgoing(x, k, p)
        sigma = im*(k-p)/(2*alpha)
        if x < 0
            u = exp(2*alpha*x)
            w = u/(1+u)
            logz = -log1p(u)
            logw = 2*alpha*x-log1p(u)
            common = -im*p*logz/(2*alpha)
            A = ws_incident(k, p)
            B = exp(loggamma(1-im*p/alpha)+loggamma(im*k/alpha)-
                    loggamma(im*(k-p)/(2*alpha))-loggamma(1+im*(k-p)/(2*alpha)))
            incoming = exp(common+im*k*logw/(2*alpha))*
                       pFq((sigma, 1+sigma), (1+im*k/alpha,), w)
            reflected = exp(common-im*k*logw/(2*alpha))*
                        pFq((1-im*(k+p)/(2*alpha), -im*(k+p)/(2*alpha)),
                            (1-im*k/alpha,), w)
            return A*incoming+B*reflected
        end
        z = 1/(1+exp(2*alpha*x))
        phase = -im*p*log(z)/(2*alpha)+im*k*log1p(-z)/(2*alpha)
        return exp(phase)*pFq((sigma, 1+sigma), (1-im*p/alpha,), z)
    end

    function ws_reference(x1, theta, smax, rtol, atol)
        if V0 == 0
            return sqrt(m/(2*pi*im*hbar*T))*exp(im*m*(x1-x0)^2/(2*hbar*T))
        end
        kstar = sqrt(2*m*V0)/hbar
        function closed(vartheta)
            k = kstar*sin(vartheta)
            local p = im*kstar*cos(vartheta)
            density = ws_outgoing(x1, k, p)*ws_outgoing(x0, -k, p)/
                      (2*pi*ws_incident(k, p)*ws_incident(-k, p))
            return density*exp(-im*hbar*k^2*T/(2*m))*kstar*cos(vartheta)
        end
        function open(t)
            k = kstar+exp(-im*theta)*t^2
            local p = sqrt(k-kstar)*sqrt(k+kstar)
            phase = -im*hbar*k^2*T/(2*m)
            if real(phase) < -700
                return 0.0im
            end
            left = ws_outgoing(x1, k, p)*ws_outgoing(x0, -k, -p)/
                   (ws_incident(k, p)*ws_incident(-k, -p))
            right = ws_outgoing(-x1, p, k)*ws_outgoing(-x0, -p, -k)/
                    (ws_incident(p, k)*ws_incident(-p, -k))
            return (left+k/p*right)/(2*pi)*exp(phase)*2*t*exp(-im*theta)
        end
        Gc, error = quadgk(closed, 0.0, pi/2; rtol=rtol, atol=atol/2)
        Go, error = quadgk(open, 0.0, smax; rtol=rtol, atol=atol/2)
        return Gc+Go
    end
    function ws_stitching(nmax, L, dQ, hc, width, rtol, atol)
        a = T/nmax
        M = round(Int, 2*L/dQ)
        Q_fine = collect(range(-L, step=dQ, length=M))
        k = 2*pi .* fftfreq(M, 1/dQ)
        V(z) = V0/2*(1+tanh(alpha*z))
        c = sqrt(m/(2*pi*im*hbar*a))
        free_I(Q, n) = exp(im*m*(Q-x0)^2/(2*a*n*hbar))/sqrt(n)

        function potential_sum(z, n)
            total = zero(z)
            for j in 1:(n-1)
                total += V(x0+j*(z-x0)/n)
            end
            return total
        end
        Jbar(Q, n) = free_I(Q, n)*exp(-im*a*potential_sum(Q, n)/hbar)

        function background(Q, n)
            mu = ((n-1)*Q+x0)/n
            A = m*n/(2*a*hbar*(n-1))
            function integrand(t)
                v = tanh(t/width)
                u = t+im*hc*v
                dz = 1+im*hc/width*(1-v^2)
                W = potential_sum(mu+u, n-1)+V(mu+u)
                return exp(im*A*u^2-im*a*W/hbar)*dz
            end
            integral, error = quadgk(integrand, -Inf, 0.0, Inf; rtol=rtol, atol=atol)
            return c/sqrt(n-1)*exp(im*m*(Q-x0)^2/(2*a*n*hbar))*integral
        end

        phase_V = exp.(-im*a .* V.(Q_fine) ./ hbar)
        multiplier = exp.(-im*a*hbar .* k.^2 ./ (2*m))
        I = free_I.(Q_fine, 1)
        for n in 2:nmax
            J = background.(Q_fine, n)
            if n > 2
                correction = ifft(fft((I .- Jbar.(Q_fine, n-1)) .* phase_V) .* multiplier)
                I = J .+ correction
            else
                I = J
            end
        end
        endpoint_factor = c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar))
        return Q_fine, endpoint_factor .* I
    end

    density_change = 0.0
    for k in [0.4, 1.0, 2.0, 4.0]
        momentum = sqrt(complex(k^2-2*m*V0/hbar^2))
        phi_left(q) = ws_outgoing(q, k, momentum)/(sqrt(2*pi)*ws_incident(k, momentum))
        direct = phi_left(1.1)*conj(phi_left(-0.2))
        if k < sqrt(2*m*V0)/hbar
            continued = ws_outgoing(1.1, k, momentum)*ws_outgoing(-0.2, -k, momentum)/
                (2*pi*ws_incident(k, momentum)*ws_incident(-k, momentum))
        else
            phi_right(q) = sqrt(k/momentum)*ws_outgoing(-q, momentum, k)/
                (sqrt(2*pi)*ws_incident(momentum, k))
            direct += phi_right(1.1)*conj(phi_right(-0.2))
            left = ws_outgoing(1.1, k, momentum)*ws_outgoing(-0.2, -k, -momentum)/
                (ws_incident(k, momentum)*ws_incident(-k, -momentum))
            right = ws_outgoing(-1.1, momentum, k)*ws_outgoing(0.2, -momentum, -k)/
                (ws_incident(momentum, k)*ws_incident(-momentum, -k))
            continued = (left+k/momentum*right)/(2*pi)
        end
        density_change = max(density_change, abs(direct-continued)/(1+abs(direct)))
    end
    println("Independent scattering-density change = ", density_change)

    x = collect(range(-10.0, 10.0, length=201))
    G_reference = [ws_reference(q, theta, smax, 1e-10, 1e-11) for q in x]
    checkpoints = [-4.0, 0.0, 4.0]
    G_control = [ws_reference(q, 0.04, 6.0, 1e-10, 1e-11) for q in checkpoints]
    G_refined = [ws_reference(q, 0.06, 7.0, 1e-12, 1e-13) for q in checkpoints]
    println("Float64 spectral reference refinement at ", checkpoints, " = ", maximum(abs.(G_control .- G_refined)))
    p_reference = plot(layout=(3, 1), size=(900, 900))
    plot!(p_reference, x, real.(G_reference), subplot=1, label="Reference", xlabel="x1", ylabel="Re G")
    plot!(p_reference, x, imag.(G_reference), subplot=2, label="Reference", xlabel="x1", ylabel="Im G")
    plot!(p_reference, x, abs2.(G_reference), subplot=3, label="Reference", xlabel="x1", ylabel="|G|²")
    Q = Float64[]
    G = ComplexF64[]
    errors = Float64[]
    for nmax in N_values
        Q, G = ws_stitching(nmax, L, dQ, 0.7, 1.0, 1e-9, 1e-10)
        indices = round.(Int, (x .+ L) ./ dQ) .+ 1
        difference = abs.(G[indices] .- G_reference)
        mean_error = sum(diff(x) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x[end]-x[1]))
        push!(errors, mean_error)
        println("N = ", nmax, ", mean complex error = ", mean_error)
        if length(errors) > 1
            println("Observed order = ", log2(errors[end-1]/errors[end]))
        end
        if nmax in [5, 20]
            plot!(p_reference, x, real.(G[indices]), subplot=1, label="N = $nmax")
            plot!(p_reference, x, imag.(G[indices]), subplot=2, label="N = $nmax")
            plot!(p_reference, x, abs2.(G[indices]), subplot=3, label="N = $nmax")
        end
    end
    function sample_grid(Q, G)
        indices = round.(Int, (x .- Q[1]) ./ (Q[2]-Q[1])) .+ 1
        return G[indices]
    end

    function mean_change(G1, G2)
        difference = abs.(G1 .- G2)
        return sum(diff(x) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x[end]-x[1]))
    end

    last = sample_grid(Q, G)
    Q_large, G_large = ws_stitching(40, 240.0, 0.05, 0.7, 1.0, 1e-9, 1e-10)
    Q_fine, G_fine = ws_stitching(40, 120.0, 0.025, 0.7, 1.0, 1e-9, 1e-10)
    println("N = 40 domain change = ", mean_change(last, sample_grid(Q_large, G_large)))
    println("N = 40 spacing change = ", mean_change(last, sample_grid(Q_fine, G_fine)))

    Q_small, G_small = ws_stitching(20, 30.0, 0.1, 0.7, 1.0, 1e-9, 1e-10)
    Q_large, G_large = ws_stitching(20, 60.0, 0.1, 0.7, 1.0, 1e-9, 1e-10)
    Q_contour, G_contour = ws_stitching(20, 30.0, 0.1, 0.7, 1.0, 1e-11, 1e-12)
    small = sample_grid(Q_small, G_small)
    large = sample_grid(Q_large, G_large)
    println("N = 20 original-grid mean error = ", mean_change(G_reference, small))
    println("N = 20 domain kernel change = ", mean_change(small, large))
    println("N = 20 reference-error score change = ", abs(mean_change(G_reference, small)-mean_change(G_reference, large)))
    println("N = 20 contour refinement = ", mean_change(small, sample_grid(Q_contour, G_contour)))

    display(p_reference)
    p = plot(N_values, errors, marker=:circle, xscale=:log10, yscale=:log10,
        xlabel="N", ylabel="Mean absolute complex error", label="Woods-Saxon", size=(900, 600))
    display(p)
end

main()
