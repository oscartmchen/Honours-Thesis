using PicardLefschetzIntegration
using QuadGK
using SpecialFunctions

function main()
    m     = 1.0
    hbar  = 1.0
    V0    = 1.0
    alpha = 1.0
    x0    = 0.0
    T     = 5.0
    nmax  = 20
    a     = T/nmax
    hc    = 0.7

    pars = parameters(δ=0.1, τ=-30.0, ϵ=0.005, N=200, n=12, dim=1)
    V(z) = V0/2*(1+tanh(alpha*z))
    c = sqrt(m/(2*pi*im*hbar*a))

    function potential_sum(z, n)
        total = zero(z)
        for j in 1:(n-1)
            total += V(x0+j*(z-x0)/n)
        end
        return total
    end

    function phase(z, Q, n)
        kinetic = m*((z-x0)^2/(n-1)+(z-Q)^2)/(2*a)
        return (kinetic-a*(potential_sum(z, n-1)+V(z)))/hbar
    end

    function calculate_J(Q, n)
        S(p) = phase(p[1], Q, n)
        contour = initialGrid([-40.0], [40.0], pars)
        flow!(S, contour, pars)
        return c/sqrt(n-1)*PL_integrate(S, contour, pars)
    end

    function reference_J(Q, n)
        mu = ((n-1)*Q+x0)/n
        function integrand(t)
            z = mu+t+im*hc*tanh(t)
            dz = 1+im*hc*(1-tanh(t)^2)
            return exp(im*phase(z, Q, n))*dz
        end
        value, error = quadgk(integrand, -Inf, 0.0, Inf; rtol=1e-11, atol=1e-12)
        return c/sqrt(n-1)*value
    end

    function real_axis_J(Q, n, cutoff, tolerance)
        mu = ((n-1)*Q+x0)/n
        A = m*n/(2*a*hbar*(n-1))
        root = sqrt(-im*A)
        right = exp(-im*a*(n-1)*V0/hbar)
        base = sqrt(pi)/(2*root)*(erfc(root*mu)+right*erfc(-root*mu))
        function integrand(z)
            tail = 0.0
            for j in 1:(n-1)
                tail += V0/(1+exp(2*alpha*j*z/(n-1)))
            end
            positive = right*expm1(im*a*tail/hbar)
            negative = expm1(-im*a*tail/hbar)
            return exp(im*A*(z-mu)^2)*positive+exp(im*A*(-z-mu)^2)*negative
        end
        value, error = quadgk(integrand, collect(0.0:1.0:cutoff)...;
            rtol=tolerance, atol=tolerance/10)
        return c/sqrt(n-1)*exp(im*m*(Q-x0)^2/(2*a*n*hbar))*(base+value)
    end

    for n in (2, 5, 20), Q in (-1.0, 0.0, 1.0)
        contour = reference_J(Q, n)
        real_axis = real_axis_J(Q, n, 24.0*(n-1), 1e-12)
        refined = real_axis_J(Q, n, 32.0*(n-1), 1e-13)
        println("n = ", n, ", Q = ", Q,
            ", real-axis/contour difference = ", abs(real_axis-contour),
            ", real-axis refinement = ", abs(real_axis-refined),
            ", package/contour difference = ", abs(calculate_J(Q, n)-contour))
    end
end

main()
