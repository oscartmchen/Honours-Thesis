import platform
import mpmath as mp


def main():
    mp.mp.dps = 50
    points = [mp.mpf(-4), mp.mpf(0), mp.mpf(4)]
    rules = {}

    def integrate(function, left, right, width, order):
        if order not in rules:
            rules[order] = mp.gauss_quadrature(order, "legendre")
        nodes, weights = rules[order]
        count = int(mp.ceil((right-left)/width))
        result = [mp.mpc(0) for x in points]
        for panel in range(count):
            lo = left+(right-left)*panel/count
            hi = left+(right-left)*(panel+1)/count
            for j in range(order):
                x = (lo+hi)/2+(hi-lo)*nodes[j]/2
                values = function(x)
                for i in range(len(points)):
                    result[i] += (hi-lo)*weights[j]*values[i]/2
        return result

    def rm_reference(s, theta, cutoff, order):
        hbar = mp.mpf("0.25")
        T = mp.mpf(10)
        x0 = mp.mpf(5) if s == 1 else mp.mpf(0)
        lam = -mp.mpf("0.5")+mp.sqrt(mp.mpc("0.25")-2*s/hbar**2)
        direction = mp.exp(-1j*theta)

        def coefficients(k):
            common = mp.power(2, 1j*k)*mp.sqrt(mp.pi)*mp.gamma(1-1j*k)
            a = common/(mp.gamma((1-lam-1j*k)/2)*mp.gamma((2+lam-1j*k)/2))
            b = -2*common/(mp.gamma((-lam-1j*k)/2)*mp.gamma((1+lam-1j*k)/2))
            return a, b

        def integrand(r):
            k = direction*r
            a, b = coefficients(k)
            am, bm = coefficients(-k)

            def parity(x):
                if x == 0:
                    return mp.mpf(1), mp.mpf(0)
                z = (1-mp.tanh(abs(x)))/2
                f = mp.exp(1j*k*abs(x))*mp.hyp2f1(-lam, lam+1, 1-1j*k, z)
                fm = mp.exp(-1j*k*abs(x))*mp.hyp2f1(-lam, lam+1, 1+1j*k, z)
                C = (bm*f-b*fm)/(-2j*k)
                S = (a*fm-am*f)/(-2j*k)
                return C, -S if x < 0 else S

            C0, S0 = parity(x0)
            phase = direction*mp.exp(-1j*hbar*k*k*T/2)*k*k/mp.pi
            result = []
            for x in points:
                C, S = parity(x)
                result.append(phase*(C*C0/(b*bm)+S*S0/(a*am)))
            return result

        return integrate(integrand, mp.mpf(0), cutoff, mp.mpf("0.5"), order)

    def ws_reference(theta, cutoff, order):
        T = mp.mpf(5)
        kstar = mp.sqrt(2)
        direction = mp.exp(-1j*theta)

        def incident(k, p):
            return mp.gamma(1-1j*p)*mp.gamma(-1j*k)/(
                mp.gamma(-1j*(k+p)/2)*mp.gamma(1-1j*(k+p)/2))

        def outgoing(x, k, p):
            sigma = 1j*(k-p)/2
            if x < 0:
                u = mp.exp(2*x)
                w = u/(1+u)
                logz = -mp.log1p(u)
                logw = 2*x-mp.log1p(u)
                common = -1j*p*logz/2
                B = mp.gamma(1-1j*p)*mp.gamma(1j*k)/(
                    mp.gamma(1j*(k-p)/2)*mp.gamma(1+1j*(k-p)/2))
                incoming = mp.exp(common+1j*k*logw/2)*mp.hyp2f1(
                    sigma, 1+sigma, 1+1j*k, w)
                reflected = mp.exp(common-1j*k*logw/2)*mp.hyp2f1(
                    1-1j*(k+p)/2, -1j*(k+p)/2, 1-1j*k, w)
                return incident(k, p)*incoming+B*reflected
            z = 1/(1+mp.exp(2*x))
            phase = -1j*p*mp.log(z)/2+1j*k*mp.log1p(-z)/2
            return mp.exp(phase)*mp.hyp2f1(sigma, 1+sigma, 1-1j*p, z)

        def closed(vartheta):
            k = kstar*mp.sin(vartheta)
            p = 1j*kstar*mp.cos(vartheta)
            factor = mp.exp(-1j*k*k*T/2)*kstar*mp.cos(vartheta)/(
                2*mp.pi*incident(k, p)*incident(-k, p))
            f0 = outgoing(mp.mpf(0), -k, p)
            return [factor*outgoing(x, k, p)*f0 for x in points]

        def open(t):
            k = kstar+direction*t*t
            p = mp.sqrt(k-kstar)*mp.sqrt(k+kstar)
            AL = incident(k, p)*incident(-k, -p)
            AR = incident(p, k)*incident(-p, -k)
            left0 = outgoing(mp.mpf(0), -k, -p)
            right0 = outgoing(mp.mpf(0), -p, -k)
            factor = mp.exp(-1j*k*k*T/2)*2*t*direction/(2*mp.pi)
            return [factor*(outgoing(x, k, p)*left0/AL+
                k/p*outgoing(-x, p, k)*right0/AR) for x in points]

        below = integrate(closed, mp.mpf(0), mp.pi/2, mp.pi/16, order)
        above = integrate(open, mp.mpf(0), cutoff, mp.mpf("0.125"), order)
        return [below[i]+above[i] for i in range(len(points))]

    print("High-precision verification of the report spectral formulas", flush=True)
    print("Python", platform.python_version(), "; mpmath", mp.__version__, flush=True)
    print("50 decimal digits; checkpoints x1 = -4, 0, 4", flush=True)
    print("These are independent verification calculations, not recovered historical code.", flush=True)
    for s in [1, -1]:
        base = rm_reference(s, mp.mpf("0.04"), mp.mpf(40), 24)
        refined = rm_reference(s, mp.mpf("0.06"), mp.mpf(48), 32)
        difference = max(abs(base[i]-refined[i]) for i in range(len(points)))
        print("Rosen-Morse sign =", s, ", angle/cutoff/order refinement =",
            mp.nstr(difference, 16), flush=True)
        if difference >= mp.mpf("1.3e-14"):
            raise ArithmeticError("Rosen-Morse reference refinement exceeds the report bound")
    base = ws_reference(mp.mpf("0.04"), mp.mpf(6), 24)
    quadrature = ws_reference(mp.mpf("0.04"), mp.mpf(6), 32)
    quadrature_change = max(abs(base[i]-quadrature[i]) for i in range(len(points)))
    print("Woods-Saxon fixed-angle order refinement =", mp.nstr(quadrature_change, 16), flush=True)
    if quadrature_change >= mp.mpf("1e-20"):
        raise ArithmeticError("Woods-Saxon quadrature is not resolved to twenty digits")
    refined = ws_reference(mp.mpf("0.06"), mp.mpf(7), 32)
    difference = max(abs(base[i]-refined[i]) for i in range(len(points)))
    print("Woods-Saxon angle/cutoff/order refinement =", mp.nstr(difference, 16), flush=True)
    if difference >= mp.mpf("6e-15"):
        raise ArithmeticError("Woods-Saxon reference refinement exceeds the report bound")


main()
