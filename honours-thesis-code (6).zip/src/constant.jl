using PicardLefschetzIntegration
using Plots
using FFTW

function main()
    m    = 1.0
    hbar = 1.0
    T    = 5.0
    x0   = 0.0
    nmax = 20
    a    = T/nmax

    F  = 0.0
    V0 = 0.0
    U  = 1.0

    V(z) = F*z + V0
    c = sqrt(m / (2*pi*im*hbar*a))

    function asymptotic_action(Q, n)
        return m*(Q-x0)^2/(2*a*n) - a*F*(n-1)*(x0+Q)/2 -
               a*(n-1)*V0 - a^3*F^2*n*(n^2-1)/(24*m)
    end

    function phase(z, Q, n)
        kinetic = m*(z-Q)^2/(2*a)
        return (asymptotic_action(z, n-1) + kinetic - a*V(z)) / hbar
    end

    pars = parameters(δ=0.05, τ=-45.0, ϵ=0.01, N=800, n=12, dim=1)
    Q_coarse = collect(-10.0:2.0:10.0)
    dQ = 0.1
    Q_fine = collect(-10.0:dQ:(10.0-dQ))

    function calculate_J(n)
        thimbles = []
        for Q in Q_coarse
            S = q -> phase(q[1], Q, n)
            contour = initialGrid([-20.0], [20.0], pars)
            flow!(S, contour, pars)
            push!(thimbles, contour)
        end

        quads = [quadrature(contour, pars) for contour in thimbles]

        J = ComplexF64[]
        for Q in Q_fine
            j = argmin(abs.(Q_coarse .- Q))
            S = q -> phase(q[1], Q, n)
            integral = PL_integrate(S, quads[j], pars)
            push!(J, c/sqrt(n-1) * integral)
        end
        return J
    end


    function Jbar(Q, n)
        return exp(im*asymptotic_action(Q, n)/hbar) / sqrt(n)
    end

    k = 2*pi .* fftfreq(length(Q_fine), 1/dQ)
    println("Stitching n = 2 of ", nmax)
    flush(stdout)
    I = []
    push!(I, exp.(im*m .* (Q_fine .- x0).^2 ./ (2*a*hbar)))
    push!(I, calculate_J(2))

    for n in 3:nmax
        println("Stitching n = ", n, " of ", nmax)
        flush(stdout)
        local J = calculate_J(n)
        local delta_I = I[n-1] .- Jbar.(Q_fine, n-1)
        local transformed = fft(delta_I .* exp.(-im*a .* V.(Q_fine) ./ hbar))
        local correction = ifft(transformed .* exp.(-im*a*hbar .* k.^2 ./ (2*m)))
        push!(I, J .+ correction)
    end

    x1 = collect(range(-5.0, 5.0, length=101))
    indices = round.(Int, (x1 .+ 10.0) ./ dQ) .+ 1
    endpoint_factor = c .* exp.(-im*a .* (V(x0) .+ V.(Q_fine)) ./ (2*hbar))
    G = (endpoint_factor .* I[nmax])[indices]
    G_reference = sqrt(m/(2*pi*im*hbar*T)) .* exp.(im*m .* (x1 .- x0).^2 ./ (2*hbar*T))
    G .*= exp(-im*U*T/hbar)
    G_reference .*= exp(-im*U*T/hbar)
    difference = abs.(G .- G_reference)
    mean_error = sum(diff(x1) .* (difference[1:end-1] .+ difference[2:end]))/(2*(x1[end]-x1[1]))
    println("N = ", nmax, ", mean complex error = ", mean_error)

    p = plot(layout=(2, 1), size=(900, 650))
    plot!(p, x1, real.(G_reference), subplot=1, label="Exact continuum", xlabel="x1", ylabel="Re G")
    scatter!(p, x1[1:4:end], real.(G[1:4:end]), subplot=1, label="Phase-transformed free, N = $nmax")
    plot!(p, x1, imag.(G_reference), subplot=2, label="Exact continuum", xlabel="x1", ylabel="Im G")
    scatter!(p, x1[1:4:end], imag.(G[1:4:end]), subplot=2, label="Phase-transformed free, N = $nmax")
    display(p)
end

main()
